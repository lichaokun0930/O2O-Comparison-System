# -*- coding: utf-8 -*-
"""
商品比对分析工具 v8.5（本地执行版）
python product_comparison_tool_local.py
.\.venv\Scripts\Activate.ps1
.\cpu_mode.ps1
.\cpu_mode.ps1
# 选择模型 5
功能:
    - 自动对比两个店铺（如美团、饿了么）的商品数据。
    - 支持“条码精确匹配”和“商品名称模糊匹配”两种模式。
    - 输出详细的 Excel 报告，包含匹配结果、独有商品等。

使用方法:
    1) 将此脚本与两个 Excel 文件放同一文件夹。
    2) 在下方 Config 中配置店铺名与文件名。
    3) 运行脚本后，结果自动写入 reports/ 目录（带时间戳）。

优化记录:
    - v8.5: 引入规格相似度维度，进一步提升匹配准确率。
    - v8.4: 调整综合评分权重并引入柔性分类相似度。
    - v8.3: 本地执行版，移除 Colab 依赖。
"""

# ==============================================================================
# 1. 自动依赖检查与导入库
# ==============================================================================
import pandas as pd
import numpy as np
import re
import jieba
import os
import logging
import torch
import time
import ssl
import urllib3
from sentence_transformers import SentenceTransformer
try:
    from sentence_transformers import CrossEncoder
except ImportError:
    CrossEncoder = None
from typing import Iterable, Optional, Tuple, List
# 使用本地实现的余弦相似度以避免依赖 scikit-learn（在 Py3.13 上可能缺少预编译轮子）
def cosine_similarity(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    """计算两组向量的余弦相似度矩阵。
    a: (N, D), b: (M, D) -> 返回 (N, M)
    支持可选 GPU 加速：设置环境变量 USE_TORCH_SIM=1 且 CUDA 可用时启用。
    """
    if a.size == 0 or b.size == 0:
        return np.zeros((a.shape[0], b.shape[0]))

    try:
        use_torch_sim = os.environ.get('USE_TORCH_SIM', '0') == '1' and torch.cuda.is_available()
    except Exception:
        use_torch_sim = False

    if use_torch_sim:
        try:
            with torch.no_grad():
                ta = torch.from_numpy(a).to('cuda', dtype=torch.float32)
                tb = torch.from_numpy(b).to('cuda', dtype=torch.float32)
                ta = torch.nn.functional.normalize(ta, p=2, dim=1)
                tb = torch.nn.functional.normalize(tb, p=2, dim=1)
                sim = ta @ tb.T
                return sim.cpu().numpy()
        except Exception as cuda_error:
            # CUDA错误处理：打印警告并回退到CPU
            print(f"⚠️ CUDA计算失败，自动切换到CPU模式: {cuda_error}")
            # 清理CUDA缓存
            try:
                torch.cuda.empty_cache()
            except:
                pass
            # 强制禁用后续GPU使用
            os.environ['USE_TORCH_SIM'] = '0'

    a_norm = np.linalg.norm(a, axis=1, keepdims=True)
    b_norm = np.linalg.norm(b, axis=1, keepdims=True)
    # 避免除零
    a_safe = a / (a_norm + 1e-12)
    b_safe = b / (b_norm + 1e-12)
    return a_safe @ b_safe.T
import warnings
import sys
import importlib
from tqdm.auto import tqdm
from tqdm.auto import tqdm as tqdm_auto
import unicodedata
import difflib
from decimal import Decimal
def _sanitize_sheet_name(name: str, existing: Optional[set] = None) -> str:
    r"""将工作表名清洗为 Excel 可接受的名称：
    - 替换非法字符 : \ / ? * [ ] 为下划线
    - 去首尾空白
    - 截断至 31 个字符
    - 保证唯一：如已存在，则追加 _1/_2 等后缀
    """
    s = str(name or '').strip()
    s = re.sub(r'[:\\/\?\*\[\]]', '_', s)
    max_len = 31
    s = s[:max_len]
    if existing is not None:
        base = s
        i = 1
        while s in existing or not s:
            suffix = f"_{i}"
            s = (base[:max_len - len(suffix)] + suffix) if len(base) + len(suffix) > max_len else base + suffix
            i += 1
        existing.add(s)
    return s

# 解决SSL证书问题和网络连接问题
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

ssl._create_default_https_context = ssl._create_unverified_context
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# 配置更好的网络重试机制
def setup_requests_session():
    session = requests.Session()
    retry_strategy = Retry(
        total=3,
        status_forcelist=[429, 500, 502, 503, 504],
        method_whitelist=["HEAD", "GET", "OPTIONS"]
    )
    adapter = HTTPAdapter(max_retries=retry_strategy)
    session.mount("http://", adapter)
    session.mount("https://", adapter)
    return session
REQUIRED_PACKAGES = [
    'pandas', 'numpy', 'jieba', 'torch', 'sentence_transformers', 'openpyxl', 'tqdm'
]

print("检查依赖库...")
for pkg in REQUIRED_PACKAGES:
    try:
        if pkg == 'sklearn':
            importlib.import_module('sklearn.metrics')
        else:
            importlib.import_module(pkg)
        print(f"[OK] {pkg} - 已安装")
    except ImportError:
        print(f"[ERROR] 缺少依赖库：{pkg}，请在终端运行：pip install {pkg}")
        sys.exit(1)
import joblib
import hashlib

warnings.filterwarnings('ignore')
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# Enable progress bars for pandas operations like .apply()
tqdm_auto.pandas()

# 兜底模式（仅当明确允许时才启用），默认禁止以保证精度
SIMPLE_FALLBACK = os.environ.get('ALLOW_SIMPLE_FALLBACK', '0') == '1'

# ==============================================================================
# 2. 日志与全局配置 (需要修改的参数都在这里)
# ==============================================================================
class Config:
    # --- 店铺名称配置 (建议使用上传目录模式，无需手动修改) ---
    # 💡 推荐：使用上传目录模式（upload/本店、upload/竞对），自动识别店铺名
    # ⚠️ 仅在禁用上传目录模式时，才需要手动修改这里的店铺名和文件名
    
    # >>> 备用配置：手动指定店铺名称和文件名 <<<
    STORE_A_NAME = '本店'  # 上传目录模式启用时，此值会被自动覆盖
    STORE_B_NAME = '竞对'  # 上传目录模式启用时，此值会被自动覆盖
    # <<< 店铺名称配置区域结束 >>>
    
    # 备用文件名（仅在上传目录中无文件时使用）
    STORE_A_FILENAME = '本店数据.xlsx'
    STORE_B_FILENAME = '竞对数据.xlsx'
    
    # 上传入口配置 - 通过不同目录区分本店和竞对（🌟推荐模式）
    UPLOAD_DIR_STORE_A = 'upload/store_a'   # 本店数据上传目录
    UPLOAD_DIR_STORE_B = 'upload/store_b'   # 竞对数据上传目录
    USE_UPLOAD_DIRS = True                  # 启用上传目录模式（推荐保持为True）
    # ⚠️ 若设为 False，将使用上面的 STORE_A_FILENAME 和 STORE_B_FILENAME
    OUTPUT_FILE = 'matched_products_comparison_final.xlsx'
    
    # 模型选项配置 - 支持多个预定义模型
    # 📌 两阶段匹配策略：
    #   1. Sentence-BERT (句向量) - 快速粗筛，将商品转为向量后计算余弦相似度
    #   2. Cross-Encoder (交叉编码器) - 精准精排，直接判断两个商品是否匹配
    AVAILABLE_MODELS = {
        '1': {
            'name': 'paraphrase-multilingual-mpnet-base-v2',
            'display_name': '标准多语言模型 (原模型)',
            'description': '通用多语言模型，成熟稳定',
            'size': '~420MB',
            'speed': '正常',
            'accuracy': '良好',
            'recommended_threshold': {'hard': 0.42, 'soft': 0.38},  # 🔧 根据18:57正常数据反推的阈值
        },
        '2': {
            'name': 'BAAI/bge-base-zh-v1.5',
            'display_name': 'BGE中文优化模型',
            'description': '专为中文优化，准确率提升15-20%',
            'size': '~560MB',
            'speed': '正常',
            'accuracy': '优秀',
            'recommended_threshold': {'hard': 0.42, 'soft': 0.38},  # 🔧 与模型1保持一致
        },
        '3': {
            'name': 'moka-ai/m3e-base',
            'display_name': 'M3E电商场景模型',
            'description': '针对电商场景优化',
            'size': '~400MB',
            'speed': '较快',
            'accuracy': '优秀',
            'recommended_threshold': {'hard': 0.42, 'soft': 0.38},  # 🔧 与模型1保持一致
        },
        '4': {
            'name': 'BAAI/bge-large-zh-v1.5',
            'display_name': 'BGE-Large 旗舰模型 ⭐',
            'description': 'BGE系列最强版本，1024维向量，准确率最高',
            'size': '~1.3GB',
            'speed': '较慢',
            'accuracy': '顶级',
            'recommended_threshold': {'hard': 0.60, 'soft': 0.55},  # 高质量模型阈值提升
        },
        '5': {
            'name': 'BAAI/bge-m3',
            'display_name': 'BGE-M3 多粒度模型',
            'description': '支持混合检索，多语言多粒度，最新一代模型',
            'size': '~2.2GB',
            'speed': '较慢',
            'accuracy': '顶级',
            'recommended_threshold': {'hard': 0.42, 'soft': 0.38},  # 🔧 回归18:57历史数据阈值，配合三级分类检查关闭
        },
        '6': {
            'name': 'BAAI/bge-small-zh-v1.5',
            'display_name': 'BGE-Small 轻量模型',
            'description': '速度快，适合大批量数据，准确率略低',
            'size': '~100MB',
            'speed': '快速',
            'accuracy': '良好+',
            'recommended_threshold': {'hard': 0.52, 'soft': 0.50},  # 轻量模型略宽松
        },
        # 🚀 高级模型选项（需要手动取消注释启用）
        # '7': {
        #     'name': 'intfloat/multilingual-e5-large',
        #     'display_name': 'E5-Large 多语言旗舰 🌍',
        #     'description': '多语言场景最强，支持100+语言，1024维向量',
        #     'size': '~2.2GB',
        #     'speed': '慢',
        #     'accuracy': '顶级+',
        #     'recommended_threshold': {'hard': 0.62, 'soft': 0.58},
        # },
        # '8': {
        #     'name': 'GanymedeNil/text2vec-large-chinese',
        #     'display_name': 'Text2Vec-Large 中文强化 🇨🇳',
        #     'description': '中文语义理解最强，1024维，电商场景优化',
        #     'size': '~1.3GB',
        #     'speed': '较慢',
        #     'accuracy': '顶级',
        #     'recommended_threshold': {'hard': 0.60, 'soft': 0.55},
        # },
        # '9': {
        #     'name': 'BAAI/bge-large-zh-v1.5',  # 备选：推荐使用选项4
        #     'display_name': 'BGE-Large-ZH v1.5 (推荐) ⭐⭐',
        #     'description': '中文商品匹配黄金标准，准确率极高',
        #     'size': '~1.3GB',
        #     'speed': '较慢',
        #     'accuracy': '顶级',
        #     'recommended_threshold': {'hard': 0.60, 'soft': 0.55},
        # },
    }
    
    # --- Cross-Encoder 可用模型配置 ---
    AVAILABLE_CROSS_ENCODERS = {
        '1': {
            'name': 'cross-encoder/ms-marco-MiniLM-L-6-v2',
            'display_name': 'MS-Marco-MiniLM (默认)',
            'description': '微软开源轻量级模型，速度快但中文效果一般',
            'size': '~90MB',
            'speed': '极快',
            'accuracy': '中等',
            'language': '英文优先'
        },
        '2': {
            'name': 'BAAI/bge-reranker-large',
            'display_name': 'BGE-Reranker-Large ⭐推荐',
            'description': '中文优化大模型，准确率提升40%，电商场景强力推荐',
            'size': '~1.3GB',
            'speed': '中',
            'accuracy': '极高',
            'language': '中英双语'
        },
        '3': {
            'name': 'BAAI/bge-reranker-base',
            'display_name': 'BGE-Reranker-Base ⚡平衡',
            'description': '速度与准确率平衡，比Large快15%，准确率提升25%',
            'size': '~309MB',
            'speed': '快',
            'accuracy': '高',
            'language': '中英双语'
        },
        '4': {
            'name': 'cross-encoder/ms-marco-MiniLM-L-12-v2',
            'display_name': 'MS-Marco-MiniLM-L12',
            'description': 'MS-Marco深层版本，准确率略高于L-6但速度较慢',
            'size': '~130MB',
            'speed': '快',
            'accuracy': '中高',
            'language': '英文优先'
        },
    }
    
    SENTENCE_BERT_MODEL = 'paraphrase-multilingual-mpnet-base-v2'  # 默认模型
    ENABLE_MODEL_SELECTION = True  # 启用运行时模型选择
    EMBEDDING_CACHE_FILE = 'embedding_cache.joblib'
    # 导出目录（相对于脚本所在目录）。默认统一写入 reports/ 便于管理
    OUTPUT_DIR = 'reports'

    # 向量编码批大小（根据GPU显存自动调整）
    # 显存 ≥8GB: 256 (最快)
    # 显存 4-8GB: 128 (平衡，默认)
    # 显存 <4GB: 64 (保守)
    # CPU模式: 32 (避免内存溢出)
    ENCODE_BATCH_SIZE = int(os.environ.get('ENCODE_BATCH_SIZE', '128'))

    # 可选：强制计算设备（'cuda' 或 'cpu'），为 None 时自动检测
    FORCE_DEVICE: Optional[str] = None

    # 是否导出清洗后的数据相关 Sheet（店A清洗、店B清洗、合并清洗对比）
    EXPORT_CLEANED_SHEETS = False

    # --- Cross-Encoder (精排模型) 配置 ---
    # Cross-Encoder 用于精确判断两个商品是否匹配，准确率远高于Sentence-BERT
    # 💡 升级建议：
    #   - 当前: ms-marco-MiniLM-L-6-v2 (英文训练，中文效果一般)
    #   - 推荐: BAAI/bge-reranker-large (中文优化，准确率提升40%)
    #   - 电商: BAAI/bge-reranker-base (速度与准确率平衡)
    USE_LOCAL_CROSS_ENCODER = False
    ONLINE_CROSS_ENCODER = 'cross-encoder/ms-marco-MiniLM-L-6-v2'  # 默认模型
    # ONLINE_CROSS_ENCODER = 'BAAI/bge-reranker-large'  # 🚀 推荐升级：中文准确率+40%
    # ONLINE_CROSS_ENCODER = 'BAAI/bge-reranker-base'   # ⚡ 平衡选项：速度快15%
    LOCAL_CROSS_ENCODER_PATH = 'D:/AI_Models/cross-encoder-model' # ‼️替换为你的模型文件夹实际路径

    # 离线首选：本地 Sentence-BERT 模型目录（包含 config.json、pytorch_model.bin/safetensors 等）
    USE_LOCAL_SENTENCE_BERT = False
    LOCAL_SENTENCE_BERT_PATH = 'D:/AI_Models/sentence-transformers/paraphrase-multilingual-mpnet-base-v2'

    # FUZZY_MATCH_PARAMS 已被移动到具体的匹配函数内部，以实现更精细的控制
    # FUZZY_MATCH_PARAMS = {
    #     "price_similarity_percent": 20,
    #     "composite_threshold": 0.2, # 🔄 Colab tuned: 0.2
    #     "strict_threshold_for_generic_cat": 0.30, # 进一步提高对“弱匹配”的审查标准
    #     "text_weight": 0.5, # 🔄 调整文本权重，为分类权重让出空间
    #     "brand_weight": 0.3, # 🔄 品牌权重30%
    #     "category_weight": 0.1, #  启用分类权重10%，提升分类匹配率
    #     "specs_weight": 0.1,
    #     "candidates_to_check": 1000, # 🔄 增大到1000，Colab中检查所有潜在匹配项
    #     "require_category_match": False, # 🔄 测试：关闭分类过滤，使用全量匹配模式
    # }

# ==============================================================================
# 3. 核心辅助函数
# ==============================================================================
# 常见品牌列表（基于数据分析扩展）
COMMON_BRANDS = [
    '君乐宝', '味全', '新希望', '公牛', '海氏海诺', '瀚思', '康益博士', '惠选', '阿尔卑斯',
    '美的', 'SKG', '麦德氏', '元气森林', 'BGM', '九阳', '小赤兔', '来乐', '古风',
    'lucky熊', '鸿尘', '冠银', '泓萱'
]
COMMON_BRANDS = [brand.lower() for brand in COMMON_BRANDS]  # 转为小写便于匹配

def clean_text(text):
    if isinstance(text, str):
        text = re.sub(r'[^\u4e00-\u9fa5a-zA-Z0-9\s]', '', text)
        return text.lower().strip()
    return ""

def extract_brand(name, vendor_category):
    if isinstance(name, str):
        name_lower = name.lower()
        match = re.search(r'[【\[（(](.*?)[】\])）]', name_lower)
        if match:
            return match.group(1).strip()
    if isinstance(vendor_category, str):
        parts = [p.strip() for p in vendor_category.split('>') if p.strip()]
        if len(parts) > 0:
            return parts[0]
    return "其他"

def extract_brand_enhanced(text):
    """提取品牌信息 - 使用扩展的品牌列表和正则匹配（Colab版本整合）"""
    if pd.isna(text) or not text:
        return ""
    
    text_lower = text.lower()
    
    # 首先检查已知品牌列表
    for brand in COMMON_BRANDS:
        if brand in text_lower:
            return brand
    
    # 英文品牌模式 (2-20字符，可含数字)
    english_pattern = r'\b([A-Za-z][A-Za-z0-9]{1,19})\b'
    # 中文品牌模式 (2-8字符)
    chinese_pattern = r'[\u4e00-\u9fff]{2,8}'
    
    matches = re.findall(english_pattern, text) + re.findall(chinese_pattern, text)
    
    if matches:
        # 返回最长的匹配项（通常是品牌名）
        return max(matches, key=len)
    
    return ""

def extract_specifications(text):
    """提取产品规格信息（Colab版本新增功能）"""
    if pd.isna(text) or not text:
        return {}
    
    text = str(text)
    specs = {}
    
    # 容量/重量规格
    volume_pattern = r'(\d+(?:\.\d+)?)\s*([mlkgL克升毫升公斤斤])'
    volume_matches = re.findall(volume_pattern, text)
    for value, unit in volume_matches:
        specs[f'容量({unit})'] = float(value)
    
    # 尺寸规格
    size_pattern = r'(\d+(?:\.\d+)?)\s*[xX*×]\s*(\d+(?:\.\d+)?)\s*[xX*×]?\s*(\d+(?:\.\d+)?)?'
    size_matches = re.findall(size_pattern, text)
    if size_matches:
        dims = size_matches[0]
        if dims[2]:  # 三维
            specs['尺寸'] = f"{dims[0]}×{dims[1]}×{dims[2]}"
        else:  # 二维
            specs['尺寸'] = f"{dims[0]}×{dims[1]}"
    
    # 功率规格
    power_pattern = r'(\d+(?:\.\d+)?)\s*(w|W|瓦|功率)'
    power_matches = re.findall(power_pattern, text)
    if power_matches:
        specs['功率(W)'] = float(power_matches[0][0])
    
    return specs

def categorize_price_band(price):
    """价格分层（Colab版本新增功能）"""
    if pd.isna(price) or price == 0:
        return "未知"
    
    if price <= 20:
        return "低价位(≤20)"
    elif price <= 50:
        return "中低价位(20-50)"
    elif price <= 100:
        return "中价位(50-100)"
    elif price <= 200:
        return "中高价位(100-200)"
    else:
        return "高价位(>200)"

def calculate_feature_similarity(features1, features2):
    """计算特征相似度（基于规格参数）（Colab版本新增功能）"""
    if not features1 or not features2:
        return 0.0
    
    # 找到共同的规格键
    common_keys = set(features1.keys()) & set(features2.keys())
    if not common_keys:
        return 0.0
    
    similarity_scores = []
    for key in common_keys:
        val1, val2 = features1[key], features2[key]
        if isinstance(val1, (int, float)) and isinstance(val2, (int, float)):
            # 数值型：计算相对差异
            max_val = max(val1, val2)
            if max_val > 0:
                similarity = 1 - abs(val1 - val2) / max_val
                similarity_scores.append(similarity)
        elif str(val1).lower() == str(val2).lower():
            # 字符型：完全匹配
            similarity_scores.append(1.0)
    
    return sum(similarity_scores) / len(similarity_scores) if similarity_scores else 0.0

def calculate_discount(row, sale_price_col, original_price_col):
    """计算折扣（Colab版本新增功能）"""
    try:
        sale_price = pd.to_numeric(row.get(sale_price_col, 0), errors='coerce')
        original_price = pd.to_numeric(row.get(original_price_col, 0), errors='coerce')
        
        if pd.isna(sale_price) or pd.isna(original_price) or original_price == 0:
            return None
            
        discount = (original_price - sale_price) / original_price * 100
        return round(discount, 2)
    except:
        return None

def tokenize_text(text):
    """文本分词（Colab版本新增功能）"""
    if pd.isna(text) or not text:
        return []
    
    text = str(text).lower()
    # 简单分词：按空格和常见分隔符分割
    import re
    tokens = re.findall(r'[\u4e00-\u9fa5a-zA-Z0-9]+', text)
    return [token for token in tokens if len(token) > 1]

def standardize_brand(brand):
    """品牌标准化（Colab版本新增功能）"""
    if pd.isna(brand) or not brand:
        return ""
    
    brand = str(brand).lower().strip()
    # 移除常见的品牌后缀
    suffixes_to_remove = ['牌', '品牌', '公司', 'co', 'ltd', 'inc']
    for suffix in suffixes_to_remove:
        if brand.endswith(suffix):
            brand = brand[:-len(suffix)].strip()
    
    return brand

def get_average_word_vector(tokens, word2vec_model, vector_size):
    """获取词向量平均值（Colab版本新增功能）"""
    if not tokens or not word2vec_model:
        return np.zeros(vector_size)
    
    vectors = []
    for token in tokens:
        try:
            if hasattr(word2vec_model, 'wv') and token in word2vec_model.wv:
                vectors.append(word2vec_model.wv[token])
            elif hasattr(word2vec_model, '__getitem__') and token in word2vec_model:
                vectors.append(word2vec_model[token])
        except:
            continue
    
    if vectors:
        return np.mean(vectors, axis=0)
    else:
        return np.zeros(vector_size)

def extract_specs(name: str) -> str:
    """从商品名称中提取规格信息"""
    if not isinstance(name, str):
        return ""
    
    # 匹配常见的规格单位
    # 例如: 500ml, 1.5L, 2kg, 300g, 12*50g, 6连包, 5片, 12支/盒
    patterns = [
        r'(\d+\.?\d*\s*[gG克])',
        r'(\d+\.?\d*\s*[kK][gG千克])',
        r'(\d+\.?\d*\s*[mM][lL毫升])',
        r'(\d+\.?\d*\s*[lL升])',
        r'(\d+\s*[\*xX]\s*\d+\s*[gG克]?)', # 12*50g
        r'(\d+\s*[连包片袋装支听])' # 6连包
    ]
    found_specs = []
    for pattern in patterns:
        matches = re.findall(pattern, name)
        found_specs.extend([re.sub(r'\s', '', m).lower() for m in matches])
    
    return " ".join(sorted(list(set(found_specs)))) # 排序去重，确保顺序不影响比较

def calculate_feature_similarity(row_a, row_b):
    # 品牌相似度计算
    brand_a = row_a.get('standardized_brand')
    brand_b = row_b.get('standardized_brand')
    brand_similarity = 1 if brand_a and brand_b and brand_a != '其他' and brand_a == brand_b else 0

    # 规格相似度计算
    specs_a = row_a.get('specs')
    specs_b = row_b.get('specs')
    specs_similarity = 1 if specs_a and specs_a == specs_b else 0

    # 🔧 新增：分类相似度计算
    # 一级分类相似度
    cat1_a = row_a.get('美团一级分类', '')
    cat1_b = row_b.get('美团一级分类', '')
    cat1_similarity = 1 if cat1_a and cat1_b and str(cat1_a) == str(cat1_b) else 0
    
    # 三级分类相似度  
    cat3_a = row_a.get('美团三级分类', '')
    cat3_b = row_b.get('美团三级分类', '')
    cat3_similarity = 1 if cat3_a and cat3_b and str(cat3_a) == str(cat3_b) else 0
    
    # 综合分类相似度（一级分类权重更高）
    category_similarity = cat1_similarity * 0.7 + cat3_similarity * 0.3

    return brand_similarity, category_similarity, specs_similarity, False  # 保持向后兼容

# === 参数覆盖/高准确率预设 ===
def _as_float(env_key: str, default: Optional[float]) -> Optional[float]:
    v = os.environ.get(env_key)
    if v is None:
        return default
    try:
        return float(v)
    except Exception:
        return default

def _as_int(env_key: str, default: Optional[int]) -> Optional[int]:
    v = os.environ.get(env_key)
    if v is None:
        return default
    try:
        return int(v)
    except Exception:
        return default

def override_match_params(params: dict, phase: str) -> dict:
    """允许通过环境变量覆盖匹配参数；并提供高准确率预设。
    可用环境变量：
      - COMPARE_STRICT=1  启用高准确率预设（更窄价格窗、更高阈值、可强制品牌一致）
      - MATCH_PRICE_WINDOW_HARD / MATCH_PRICE_WINDOW_SOFT （百分比整数，如 15）
      - MATCH_THRESHOLD_HARD / MATCH_THRESHOLD_SOFT （0-1 浮点）
      - MATCH_TEXT_WEIGHT / MATCH_BRAND_WEIGHT / MATCH_CATEGORY_WEIGHT / MATCH_SPECS_WEIGHT
      - MATCH_REQUIRE_BRAND=1  强制品牌一致（当两侧品牌均非空且非“其他”）
    """
    phase_upper = (phase or '').upper()
    out = dict(params)

    # 预设：高准确率
    if os.environ.get('COMPARE_STRICT', '0') == '1':
        if phase_upper == 'HARD':
            out['price_similarity_percent'] = min(out.get('price_similarity_percent', 15), 12)
            out['composite_threshold'] = max(out.get('composite_threshold', 0.5), 0.6)
        else:  # SOFT
            out['price_similarity_percent'] = min(out.get('price_similarity_percent', 20), 15)
            out['composite_threshold'] = max(out.get('composite_threshold', 0.3), 0.55)  # 🔧 兼容高质量模型(如BGE-M3)
        # 提升文本/品牌权重（更保守）
        out['text_weight'] = max(out.get('text_weight', 0.5), 0.6)
        out['brand_weight'] = max(out.get('brand_weight', 0.3), 0.35)
        out['require_brand_match'] = True

    # 细粒度覆盖
    price_env = _as_int(f"MATCH_PRICE_WINDOW_{phase_upper}", None)
    if price_env is not None:
        out['price_similarity_percent'] = price_env
    thr_env = _as_float(f"MATCH_THRESHOLD_{phase_upper}", None)
    if thr_env is not None:
        out['composite_threshold'] = thr_env

    tw = _as_float('MATCH_TEXT_WEIGHT', None)
    bw = _as_float('MATCH_BRAND_WEIGHT', None)
    cw = _as_float('MATCH_CATEGORY_WEIGHT', None)
    sw = _as_float('MATCH_SPECS_WEIGHT', None)
    if tw is not None: out['text_weight'] = tw
    if bw is not None: out['brand_weight'] = bw
    if cw is not None: out['category_weight'] = cw
    if sw is not None: out['specs_weight'] = sw

    if os.environ.get('MATCH_REQUIRE_BRAND', '0') == '1':
        out['require_brand_match'] = True
    if os.environ.get('MATCH_REQUIRE_CAT3', '0') == '1':
        out['require_cat3_match'] = True
    if os.environ.get('MATCH_REQUIRE_SPECS', '0') == '1':
        out['require_specs_match'] = True
    mto = _as_int('MATCH_MIN_TOKEN_OVERLAP', None)
    if mto is not None:
        out['min_token_overlap'] = max(0, int(mto))

    return out

def load_and_process_store_data(filepath: str, model: Optional[SentenceTransformer], cache_path: str = None, role: Optional[str] = None) -> Tuple[pd.DataFrame, pd.DataFrame]:
    if not filepath or not os.path.exists(filepath):
        logging.error(f"文件路径无效: {filepath}")
        return pd.DataFrame(), pd.DataFrame()

    try:
        # 尝试多种编码读取 Excel（修复 GBK 编码错误）
        try:
            df = pd.read_excel(filepath, engine='openpyxl')
        except Exception as e1:
            try:
                df = pd.read_excel(filepath, engine='xlrd')
            except Exception as e2:
                # 如果是 CSV 文件，尝试多种编码
                if filepath.lower().endswith('.csv'):
                    for encoding in ['utf-8', 'gbk', 'gb2312', 'utf-8-sig']:
                        try:
                            df = pd.read_csv(filepath, encoding=encoding)
                            break
                        except Exception:
                            continue
                    else:
                        raise Exception(f"无法用任何编码读取 CSV 文件: {e1}")
                else:
                    raise Exception(f"Excel 读取失败: {e1}")
    except Exception as e:
        logging.error(f"读取文件 {filepath} 失败: {e}")
        return pd.DataFrame(), pd.DataFrame()

    # 标准化列名：去除空格和特殊字符
    df.columns = df.columns.str.strip()  # 去除首尾空格
    df.columns = df.columns.str.replace(r'\s+', '', regex=True)  # 去除所有空格
    
    # 定义必需列和可选列
    required_cols = ['商品名称', '原价', '售价']  # 核心必需列
    optional_cols = ['条码', '商家分类', '月售', '库存', '美团一级分类', '美团三级分类', '店内码', '规格', '单位']  # 可选列
    
    # 检查必需列
    missing_required = [col for col in required_cols if col not in df.columns]
    if missing_required:
        logging.error(f"文件缺少必需列: {missing_required}")
        return pd.DataFrame(), pd.DataFrame()
    
    # 自动补充可选列（允许本店和竞对列不一致）
    for col in optional_cols:
        if col not in df.columns:
            df[col] = np.nan
            logging.info(f"文件中缺少「{col}」列，已自动填充为空值。")

    # 条码统一归一化：
    # - 去科学计数法（1.234E+12 -> 1234000000000）
    # - 去小数（1234567890123.0 -> 1234567890123）
    # - 去非数字字符
    # 注意：若源文件在 Excel 中已以数字格式保存且丢失前导零，则无法还原前导零；建议在源文件中将条码列设为“文本”。
    def _normalize_barcode(v):
        if pd.isna(v):
            return np.nan
        s = str(v).strip()
        if not s:
            return np.nan
        # 科学计数法 -> 十进制字符串
        if 'e' in s.lower():
            try:
                s = format(Decimal(s), 'f')
            except Exception:
                pass
        # 去小数部分
        if '.' in s:
            s = s.split('.')[0]
        # 仅保留数字
        s = re.sub(r'\D', '', s)
        return s or np.nan

    try:
        df['条码'] = df['条码'].apply(_normalize_barcode).astype('object')
    except Exception:
        # 兜底：尽量不让条码列导致崩溃
        df['条码'] = df['条码'].astype(str).str.replace(r'\.0$', '', regex=True).str.strip()
        df['条码'].replace(['nan', 'None', ''], np.nan, inplace=True)
    df['cleaned_商品名称'] = df['商品名称'].apply(clean_text)
    df['standardized_brand'] = df.apply(lambda row: extract_brand(row['商品名称'], row['商家分类']), axis=1)
    df['specs'] = df['商品名称'].apply(extract_specs) # 新增：提取规格

    # 兼容分类字段
    df['一级分类'] = df['美团一级分类'].fillna(df['商家分类'].apply(lambda x: str(x).split('>')[0] if pd.notna(x) else ''))
    
    def get_cat3(row):
        if pd.notna(row['美团三级分类']):
            return row['美团三级分类']
        if pd.notna(row['商家分类']) and '>' in str(row['商家分类']):
            parts = str(row['商家分类']).split('>')
            return parts[2] if len(parts) > 2 else parts[-1]  # 优先取第三级，否则取最后一级
        return ''
    df['三级分类'] = df.apply(get_cat3, axis=1)
    df['cleaned_一级分类'] = df['一级分类'].apply(clean_text)
    df['cleaned_三级分类'] = df['三级分类'].apply(clean_text)

    # === 向量编码前：可选预过滤（按一级分类）与采样，减少计算规模 ===
    try:
        cat_list_env = os.environ.get('COMPARE_CAT1_LIST')
        cat_regex_env = os.environ.get('COMPARE_CAT1_REGEX')
        original_len = len(df)
        if cat_list_env:
            items = [s.strip().lower() for s in re.split(r'[;,，；]\s*', cat_list_env) if s.strip()]
            df = df[df['一级分类'].astype(str).str.lower().isin(items)]
        if cat_regex_env:
            pattern = re.compile(cat_regex_env, flags=re.IGNORECASE)
            df = df[df['一级分类'].astype(str).apply(lambda s: bool(pattern.search(s)))]
        if len(df) != original_len:
            logging.info(f"预过滤(一级分类)后：{original_len} -> {len(df)}")

        # 采样上限（仅测试用）：COMPARE_MAX_A / COMPARE_MAX_B
        if role:
            max_key = f"COMPARE_MAX_{role.upper()}"
            max_n = os.environ.get(max_key)
            if max_n and str(max_n).isdigit():
                n = int(max_n)
                if n > 0 and len(df) > n:
                    df = df.head(n)
                    logging.info(f"应用{max_key}={n}：截取前 {n} 条用于快速测试")
    except Exception as _:
        pass

    # --- 向量生成与缓存 ---
    if SIMPLE_FALLBACK or model is None:
        logging.info("简化兜底模式：跳过向量编码，后续采用轻量文本相似度（无需模型）")
        # 放一个占位列，保持后续流程不报错
        df['vector'] = [np.zeros(1)] * len(df)
    else:
        logging.info(f"正在为「{os.path.basename(filepath)}」的商品生成文本向量...")
        texts = (df['cleaned_商品名称'] + ' ' + df['cleaned_一级分类'] + ' ' + df['cleaned_三级分类']).astype(str).tolist()
        if cache_path:
            # 使用缓存逻辑
            try:
                cache = joblib.load(cache_path)
            except FileNotFoundError:
                cache = {}

            texts_to_encode = []
            indices_to_encode = []
            final_embeddings = [None] * len(df)
            
            for i, text in enumerate(texts):
                key = hashlib.sha256(text.encode()).hexdigest()
                if key in cache:
                    final_embeddings[i] = cache[key]
                else:
                    texts_to_encode.append(text)
                    indices_to_encode.append(i)

            if texts_to_encode:
                logging.info(f"缓存未命中 {len(texts_to_encode)} 条，正在计算新向量...")
                t0 = time.perf_counter()
                new_embeddings = model.encode(texts_to_encode, show_progress_bar=True, batch_size=Config.ENCODE_BATCH_SIZE)
                t1 = time.perf_counter()
                logging.info(f"向量编码完成：新增 {len(texts_to_encode)} 条，用时 {t1 - t0:.2f}s，batch_size={Config.ENCODE_BATCH_SIZE}")
                
                for i, embedding in enumerate(new_embeddings):
                    original_index = indices_to_encode[i]
                    final_embeddings[original_index] = embedding
                    key = hashlib.sha256(texts_to_encode[i].encode()).hexdigest()
                    cache[key] = embedding
                joblib.dump(cache, cache_path)
            embeddings = final_embeddings
        else:
            # 直接计算向量，不使用缓存
            t0 = time.perf_counter()
            embeddings = model.encode(texts, show_progress_bar=True, batch_size=Config.ENCODE_BATCH_SIZE)
            t1 = time.perf_counter()
            logging.info(f"向量编码完成：共 {len(texts)} 条，用时 {t1 - t0:.2f}s，batch_size={Config.ENCODE_BATCH_SIZE}")
        df['vector'] = list(embeddings)

    df_with_barcode = df[df['条码'].notna()].copy().drop_duplicates(subset=['条码'], keep='first')
    df_no_barcode = df[df['条码'].isna()].copy()

    logging.info(f"处理完成: 总商品 {len(df)} | 有条码 {len(df_with_barcode)} | 无条码 {len(df_no_barcode)}")
    return df_with_barcode, df_no_barcode

def check_model_exists(model_name: str) -> bool:
    """检查SentenceTransformer模型是否已缓存到本地"""
    import torch
    from pathlib import Path
    
    # 检查HuggingFace Hub缓存位置（新版本的缓存结构）
    hub_cache_path = Path.home() / ".cache" / "huggingface" / "hub" / f"models--sentence-transformers--{model_name}"
    
    if hub_cache_path.exists():
        # 检查是否有snapshots目录和模型文件
        snapshots_dir = hub_cache_path / "snapshots"
        if snapshots_dir.exists():
            # 查找任何子目录中的模型文件
            for snapshot_dir in snapshots_dir.iterdir():
                if snapshot_dir.is_dir():
                    model_files = list(snapshot_dir.glob("*.safetensors")) + list(snapshot_dir.glob("*.bin")) + list(snapshot_dir.glob("pytorch_model.bin"))
                    if model_files:
                        return True
    
    # 检查旧版本的缓存位置
    old_cache_paths = [
        Path.home() / ".cache" / "torch" / "sentence_transformers" / model_name.replace("/", "_"),
        Path.home() / ".cache" / "huggingface" / "transformers" / model_name.replace("/", "_"),
    ]
    
    for path in old_cache_paths:
        if path.exists() and (list(path.glob("*.bin")) or list(path.glob("*.safetensors"))):
            return True
    
    return False

# ==============================================================================
# 4. 主流程函数
# ==============================================================================

def _normalize_filename_for_match(name: str) -> str:
    """
    用于文件名宽松匹配的归一化：
    - NFKC 规整（全角->半角）
    - 小写、去首尾空白
    - 统一短横线/破折号：—、–、－ -> -
    - 去除所有空白字符
    - 移除常见扩展名后缀（.xlsx/.xls）
    - 统一中文括号为英文括号
    """
    if not isinstance(name, str):
        name = str(name or "")
    s = unicodedata.normalize('NFKC', name).lower().strip()
    s = s.replace('—', '-').replace('–', '-').replace('－', '-')
    s = s.replace('（', '(').replace('）', ')').replace('【', '[').replace('】', ']')
    # 去除扩展名
    s = re.sub(r"\.(xlsx|xls)$", "", s)
    # 去除所有空白
    s = re.sub(r"\s+", "", s)
    return s

def get_adaptive_threshold(model_name: str, cfg, match_type: str = 'soft') -> float:
    """根据模型自动获取推荐阈值
    
    Args:
        model_name: 模型名称
        cfg: 配置对象
        match_type: 'hard' 或 'soft'
    
    Returns:
        推荐的阈值
    """
    models = getattr(cfg, 'AVAILABLE_MODELS', {})
    
    # 查找模型对应的推荐阈值
    for model_info in models.values():
        if model_info['name'] == model_name:
            thresholds = model_info.get('recommended_threshold', {'hard': 0.5, 'soft': 0.5})
            threshold = thresholds.get(match_type, 0.5)
            print(f"📊 [{match_type.upper()}匹配] 当前模型推荐阈值: {threshold:.2f}")
            return threshold
    
    # 默认阈值
    print(f"⚠️ 未找到模型配置，使用默认阈值: 0.5")
    return 0.5

def select_embedding_model(cfg) -> str:
    """交互式选择嵌入模型"""
    if not getattr(cfg, 'ENABLE_MODEL_SELECTION', True):
        return cfg.SENTENCE_BERT_MODEL
    
    # 检查是否通过环境变量指定了模型
    env_model = os.environ.get('SENTENCE_BERT_MODEL')
    if env_model:
        print(f"🔧 通过环境变量指定模型: {env_model}")
        return env_model
    
    # 检测标准输入是否可用（是否被重定向或管道输入）
    import sys
    if not sys.stdin.isatty():
        print("ℹ️ 检测到非交互式模式（标准输入被重定向），使用默认模型")
        return cfg.SENTENCE_BERT_MODEL
    
    print("\n" + "="*70)
    print("🤖 嵌入模型选择")
    print("="*70)
    print("请选择用于商品比对的嵌入模型：\n")
    
    models = getattr(cfg, 'AVAILABLE_MODELS', {})
    if not models:
        return cfg.SENTENCE_BERT_MODEL
    
    # 显示模型选项
    for key, model_info in sorted(models.items()):
        print(f"  [{key}] {model_info['display_name']}")
        print(f"      📝 说明: {model_info['description']}")
        print(f"      📦 大小: {model_info['size']} | ⚡ 速度: {model_info['speed']} | 🎯 准确率: {model_info['accuracy']}")
        print()
    
    print("💡 提示:")
    print("   - 选项4 (BGE-Large) ⭐ 最强性能，准确率最高，适合高质量要求场景")
    print("   - 选项5 (BGE-M3) 最新一代，支持混合检索，多语言场景最优")
    print("   - 选项2 (BGE-Base) 性能与速度平衡，推荐日常使用")
    print("   - 选项6 (BGE-Small) 速度最快，适合大批量数据处理")
    print("   - 首次使用新模型需要下载，约5-30分钟（视模型大小）")
    print()
    
    # 获取用户选择
    while True:
        try:
            choice = input("请输入模型编号 (1-6, 回车=使用默认模型1): ").strip()
            
            # 默认选择
            if not choice:
                choice = '1'
                print(f"✅ 使用默认模型: {models['1']['display_name']}")
            
            if choice in models:
                selected_model = models[choice]['name']
                print(f"\n✅ 已选择: {models[choice]['display_name']}")
                print(f"   模型路径: {selected_model}")
                print(f"   预期效果: {models[choice]['description']}")
                print("="*70)
                return selected_model
            else:
                print(f"❌ 无效选择，请输入 1-{len(models)} 之间的数字")
        except KeyboardInterrupt:
            print("\n\n⚠️ 用户取消选择，使用默认模型")
            return cfg.SENTENCE_BERT_MODEL
        except Exception as e:
            print(f"❌ 输入错误: {e}，请重新输入")

def select_cross_encoder_model(cfg) -> str:
    """交互式选择 Cross-Encoder 精排模型"""
    if not getattr(cfg, 'ENABLE_MODEL_SELECTION', True):
        return cfg.ONLINE_CROSS_ENCODER
    
    # 检查是否通过环境变量指定了模型
    env_model = os.environ.get('CROSS_ENCODER_MODEL')
    if env_model:
        print(f"🔧 通过环境变量指定 Cross-Encoder 模型: {env_model}")
        return env_model
    
    # 检测标准输入是否可用
    import sys
    if not sys.stdin.isatty():
        print("ℹ️ 检测到非交互式模式，使用默认 Cross-Encoder 模型")
        return cfg.ONLINE_CROSS_ENCODER
    
    print("\n" + "="*70)
    print("🎯 Cross-Encoder 精排模型选择")
    print("="*70)
    print("Cross-Encoder 用于精准精排，提升匹配准确率\n")
    
    models = getattr(cfg, 'AVAILABLE_CROSS_ENCODERS', {})
    if not models:
        return cfg.ONLINE_CROSS_ENCODER
    
    # 显示模型选项
    for key, model_info in sorted(models.items()):
        print(f"  [{key}] {model_info['display_name']}")
        print(f"      📝 说明: {model_info['description']}")
        print(f"      📦 大小: {model_info['size']} | ⚡ 速度: {model_info['speed']} | 🎯 准确率: {model_info['accuracy']}")
        print(f"      🌐 语言: {model_info['language']}")
        print()
    
    print("💡 提示:")
    print("   - 选项2 (BGE-Reranker-Large) ⭐ 中文场景强力推荐，准确率+40%")
    print("   - 选项3 (BGE-Reranker-Base) ⚡ 速度与准确率平衡，准确率+25%")
    print("   - 选项1 (MS-Marco-MiniLM) 速度最快，但中文效果一般")
    print("   - Cross-Encoder 与 Sentence-BERT 配合使用，两阶段匹配更精准")
    print("   - 首次使用新模型需要下载，约1-10分钟（视模型大小）")
    print()
    
    # 获取用户选择
    while True:
        try:
            choice = input(f"请输入模型编号 (1-{len(models)}, 回车=使用默认模型1): ").strip()
            
            # 默认选择
            if not choice:
                choice = '1'
                print(f"✅ 使用默认模型: {models['1']['display_name']}")
            
            if choice in models:
                selected_model = models[choice]['name']
                print(f"\n✅ 已选择: {models[choice]['display_name']}")
                print(f"   模型路径: {selected_model}")
                print(f"   预期效果: {models[choice]['description']}")
                print("="*70)
                return selected_model
            else:
                print(f"❌ 无效选择，请输入 1-{len(models)} 之间的数字")
        except KeyboardInterrupt:
            print("\n\n⚠️ 用户取消选择，使用默认模型")
            return cfg.ONLINE_CROSS_ENCODER
        except Exception as e:
            print(f"❌ 输入错误: {e}，请重新输入")

def scan_excel_files_in_dir(directory: str) -> List[str]:
    """扫描指定目录中的所有Excel文件"""
    excel_files = []
    if not os.path.exists(directory):
        return excel_files
    try:
        for f in os.listdir(directory):
            if f.lower().endswith((".xlsx", ".xls")) and not f.startswith("~$"):
                excel_files.append(f)
    except Exception as e:
        logging.error(f"❌ 扫描目录 {directory} 时出错：{e}")
    return sorted(excel_files)

def get_latest_file_from_upload_dir(upload_dir: str, store_type: str) -> Tuple[Optional[str], str]:
    """从上传目录获取最新的Excel文件，返回(文件路径, 店铺名称)"""
    base_dir = os.path.dirname(os.path.abspath(__file__))
    full_upload_dir = os.path.join(base_dir, upload_dir)
    
    # 确保目录存在
    if not os.path.exists(full_upload_dir):
        return None, ""
    
    excel_files = scan_excel_files_in_dir(full_upload_dir)
    
    if not excel_files:
        return None, ""
    
    # 如果有多个文件，选择最新的
    if len(excel_files) > 1:
        files_with_time = []
        for f in excel_files:
            filepath = os.path.join(full_upload_dir, f)
            mtime = os.path.getmtime(filepath)
            files_with_time.append((f, mtime, filepath))
        
        # 按修改时间排序，最新的在前
        files_with_time.sort(key=lambda x: x[1], reverse=True)
        latest_file = files_with_time[0][2]
        latest_filename = files_with_time[0][0]
        
        print(f"📋 {store_type}上传目录发现 {len(excel_files)} 个文件，使用最新文件: {latest_filename}")
        if len(excel_files) > 1:
            print(f"   💡 提示: 其他文件将被忽略")
            for fname, mtime, _ in files_with_time[1:]:
                mtime_str = time.strftime("%Y-%m-%d %H:%M", time.localtime(mtime))
                print(f"      - {fname} ({mtime_str})")
    else:
        latest_file = os.path.join(full_upload_dir, excel_files[0])
        latest_filename = excel_files[0]
    
    # 从文件名提取店铺名称
    store_name = os.path.splitext(latest_filename)[0][:40]
    
    return latest_file, store_name

def detect_files_from_upload_dirs(cfg) -> Tuple[Optional[str], Optional[str], str, str]:
    """从上传目录检测文件，返回(本店文件路径, 竞对文件路径, 本店名称, 竞对名称)"""
    base_dir = os.path.dirname(os.path.abspath(__file__))
    
    upload_a_dir = getattr(cfg, 'UPLOAD_DIR_STORE_A', 'upload/store_a')
    upload_b_dir = getattr(cfg, 'UPLOAD_DIR_STORE_B', 'upload/store_b')
    
    print("\n" + "="*60)
    print("📂 Upload Directory Detection")
    print("="*60)
    print(f"📁 Store A: {upload_a_dir}")
    print(f"📁 Store B: {upload_b_dir}")
    print()
    
    # 检测本店文件
    store_a_file, store_a_name = get_latest_file_from_upload_dir(upload_a_dir, "Store A")
    
    # 检测竞对文件
    store_b_file, store_b_name = get_latest_file_from_upload_dir(upload_b_dir, "Store B")
    
    # 显示检测结果
    if store_a_file:
        size = os.path.getsize(store_a_file)
        size_str = f"{size/1024:.1f}KB" if size < 1024*1024 else f"{size/(1024*1024):.1f}MB"
        mtime = os.path.getmtime(store_a_file)
        mtime_str = time.strftime("%Y-%m-%d %H:%M", time.localtime(mtime))
        print(f"✅ Store A: {store_a_name}.xlsx ({size_str}, {mtime_str})")
    else:
        print(f"❌ Store A: No Excel files found")
    
    if store_b_file:
        size = os.path.getsize(store_b_file)
        size_str = f"{size/1024:.1f}KB" if size < 1024*1024 else f"{size/(1024*1024):.1f}MB"
        mtime = os.path.getmtime(store_b_file)
        mtime_str = time.strftime("%Y-%m-%d %H:%M", time.localtime(mtime))
        print(f"✅ Store B: {store_b_name}.xlsx ({size_str}, {mtime_str})")
    else:
        print(f"❌ Store B: No Excel files found")
    
    print("="*60)
    
    return store_a_file, store_b_file, store_a_name, store_b_name

def get_local_filepath(filename: str) -> Optional[str]:
    current_directory = os.path.dirname(os.path.abspath(__file__))
    # 1) 精确匹配（包含原扩展名）
    filepath = os.path.join(current_directory, filename)
    if os.path.exists(filepath):
        logging.info(f"✅ 文件 '{filename}' 已找到。")
        return filepath

    # 2) 宽松匹配：在同目录查找 .xls/.xlsx，做归一化比对（跳过 ~$/临时文件）
    try:
        target_norm = _normalize_filename_for_match(filename)
        candidates = [f for f in os.listdir(current_directory) if f.lower().endswith((".xlsx", ".xls")) and not f.startswith("~$")]
        # 先尝试归一化完全相等
        for cand in candidates:
            if _normalize_filename_for_match(cand) == target_norm:
                path = os.path.join(current_directory, cand)
                logging.info(f"✅ 未找到精确同名，但找到归一化匹配文件：'{cand}'（由 '{filename}' 匹配）")
                return path
        # 再尝试相似度匹配（≥0.9）
        ratios = [(cand, difflib.SequenceMatcher(None, _normalize_filename_for_match(cand), target_norm).ratio()) for cand in candidates]
        if ratios:
            best_cand, best_score = max(ratios, key=lambda x: x[1])
            if best_score >= 0.9:
                path = os.path.join(current_directory, best_cand)
                logging.warning(f"⚠️ 精确文件未找到，使用相似文件：'{best_cand}'（相似度 {best_score:.2f}，由 '{filename}' 匹配）")
                return path
        logging.error(f"❌ 错误：文件 '{filename}' 在脚本所在目录未找到！当前目录为：{current_directory}。目录内可用文件：{candidates}")
        return None
    except Exception as e:
        logging.error(f"❌ 在目录 '{current_directory}' 搜索文件时出错：{e}")
        return None

def match_by_barcode(df_a: pd.DataFrame, df_b: pd.DataFrame, name_a: str, name_b: str) -> pd.DataFrame:
    if df_a.empty or df_b.empty:
        return pd.DataFrame()

    merged = pd.merge(df_a, df_b, on='条码', how='inner', suffixes=(f'_{name_a}', f'_{name_b}'))
    if merged.empty:
        return merged

    def _ensure_suffix(columns: Iterable[str], suffix: str) -> None:
        for col in columns:
            if col == '条码':
                continue
            target = f"{col}_{suffix}"
            if target in merged.columns:
                continue
            if col in merged.columns:
                merged.rename(columns={col: target}, inplace=True)

    _ensure_suffix(df_a.columns, name_a)
    _ensure_suffix(df_b.columns, name_b)

    # 为两侧补充带后缀的条码列，便于下游稳定引用
    barcode_col_a = f"条码_{name_a}"
    barcode_col_b = f"条码_{name_b}"
    if barcode_col_a not in merged.columns:
        merged[barcode_col_a] = merged['条码']
    if barcode_col_b not in merged.columns:
        merged[barcode_col_b] = merged['条码']
    return merged

def perform_hard_category_matching(df_a: pd.DataFrame, df_b: pd.DataFrame, name_a: str, name_b: str, cross_encoder=None, cfg=None) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """
    阶段一：硬分类优先匹配
    - 找出A店和B店中，一级分类和三级分类完全一致的商品。
    - 在这些分类完全相同的分组内，进行高精度的模糊匹配。
    - 返回匹配上的商品，以及A店和B店中未匹配的商品。
    """
    if df_a.empty or df_b.empty:
        return pd.DataFrame(), df_a, df_b

    # 确保分类列存在
    if '一级分类' not in df_a.columns or '三级分类' not in df_a.columns or \
       '一级分类' not in df_b.columns or '三级分类' not in df_b.columns:
        logging.warning("⚠️ 硬分类匹配阶段缺少分类列，跳过此阶段。")
        return pd.DataFrame(), df_a, df_b

    # 创建唯一的分类ID
    df_a['category_id'] = df_a['一级分类'].astype(str) + '_' + df_a['三级分类'].astype(str)
    df_b['category_id'] = df_b['一级分类'].astype(str) + '_' + df_b['三级分类'].astype(str)

    # 找出共有的分类ID
    common_categories = set(df_a['category_id']) & set(df_b['category_id'])
    logging.info(f"硬分类匹配：找到 {len(common_categories)} 个共同的商品分类。")

    all_hard_matches = []
    
    # 获取自适应阈值
    adaptive_threshold = 0.5  # 默认值
    if cfg:
        adaptive_threshold = get_adaptive_threshold(cfg.SENTENCE_BERT_MODEL, cfg, match_type='hard')
    
    # 复制一份参数用于硬匹配，通常硬匹配的阈值可以更高
    hard_match_params = {
        "price_similarity_percent": 15,
        "composite_threshold": adaptive_threshold,  # 使用自适应阈值
        "text_weight": 0.6, # 提升文本权重
        "brand_weight": 0.3, # 品牌权重
        "specs_weight": 0.1, # 规格权重
        "category_weight": 0.0, # 硬分类匹配阶段，分类已100%相同，权重为0
        "candidates_to_check": int(os.environ.get('MATCH_TOPK_HARD', '20')),
        "require_category_match": False, # 在这个函数内部，分类已经匹配，不需要再次检查
        "require_cat3_match": False,  # ✅ 硬分类已经按category_id分组，无需二次检查
    }
    hard_match_params = override_match_params(hard_match_params, phase='HARD')

    # 记录所有在硬匹配中处理过的商品索引
    matched_indices_a = set()
    matched_indices_b = set()

    for category in tqdm(common_categories, desc="硬分类匹配进度", dynamic_ncols=True, mininterval=0.5, ascii=True, file=sys.stdout):
        group_a = df_a[df_a['category_id'] == category]
        group_b = df_b[df_b['category_id'] == category]

        if group_a.empty or group_b.empty:
            continue

        # 在分类分组内进行模糊匹配
        # 注意：这里调用的是一个通用的匹配核心逻辑，我们把它命名为 _core_fuzzy_match
        matches_in_group = _core_fuzzy_match(group_a, group_b, name_a, name_b, hard_match_params, cross_encoder)

        if not matches_in_group.empty:
            all_hard_matches.append(matches_in_group)
            
            # 记录被匹配上的商品原始索引
            matched_indices_a.update(matches_in_group[f'index_{name_a}'].tolist())
            matched_indices_b.update(matches_in_group[f'index_{name_b}'].tolist())

    if not all_hard_matches:
        return pd.DataFrame(), df_a.drop(columns=['category_id']), df_b.drop(columns=['category_id'])

    final_hard_matches = pd.concat(all_hard_matches, ignore_index=True)

    # 找出未匹配的商品
    unmatched_a = df_a[~df_a.index.isin(matched_indices_a)].copy()
    unmatched_b = df_b[~df_b.index.isin(matched_indices_b)].copy()

    # 清理辅助列
    final_hard_matches = final_hard_matches.drop(columns=[f'index_{name_a}', f'index_{name_b}'], errors='ignore')
    unmatched_a = unmatched_a.drop(columns=['category_id'], errors='ignore')
    unmatched_b = unmatched_b.drop(columns=['category_id'], errors='ignore')
    
    return final_hard_matches, unmatched_a, unmatched_b


def perform_soft_fuzzy_matching(df_a: pd.DataFrame, df_b: pd.DataFrame, name_a: str, name_b: str, cross_encoder=None, cfg=None) -> pd.DataFrame:
    """
    阶段二：软分类兜底匹配
    - 对所有在硬分类匹配中未找到匹配的剩余商品进行匹配。
    - ✅ 性能优化：改为按一级分类分组匹配，避免全量比对
    """
    if df_a.empty or df_b.empty:
        return pd.DataFrame()

    # 确保分类列存在
    if '一级分类' not in df_a.columns or '一级分类' not in df_b.columns:
        logging.warning("⚠️ 软分类匹配阶段缺少一级分类列，使用全量匹配（性能较差）。")
        return _perform_soft_match_without_grouping(df_a, df_b, name_a, name_b, cross_encoder, cfg)
    
    # ✅ 性能优化：按一级分类分组匹配
    df_a['cat1_group'] = df_a['一级分类'].astype(str)
    df_b['cat1_group'] = df_b['一级分类'].astype(str)
    
    common_cat1 = set(df_a['cat1_group']) & set(df_b['cat1_group'])
    logging.info(f"软分类匹配：找到 {len(common_cat1)} 个共同的一级分类，将分组处理（避免全量比对）")
    
    all_soft_matches = []
    matched_indices_a = set()
    matched_indices_b = set()
    
    # 获取自适应阈值
    adaptive_threshold = 0.5
    if cfg:
        adaptive_threshold = get_adaptive_threshold(cfg.SENTENCE_BERT_MODEL, cfg, match_type='soft')
    
    # 软匹配参数
    soft_match_params = {
        "price_similarity_percent": 20,
        "composite_threshold": adaptive_threshold,
        "text_weight": 0.5,
        "brand_weight": 0.3,
        "category_weight": 0.1,
        "specs_weight": 0.1,
        "candidates_to_check": int(os.environ.get('MATCH_TOPK_SOFT', '100')),
        "require_category_match": False,  # ✅ 已分组，无需再检查一级分类
        "require_cat3_match": True,  # 🔧 开启三级分类强制匹配
        "require_brand_match": False,  # 可选：设为True强制品牌一致
    }
    soft_match_params = override_match_params(soft_match_params, phase='SOFT')
    
    # 按一级分类分组匹配
    for cat1 in tqdm(common_cat1, desc="软分类匹配进度（分组优化）", dynamic_ncols=True, mininterval=0.5, ascii=True, file=sys.stdout):
        group_a = df_a[df_a['cat1_group'] == cat1]
        group_b = df_b[df_b['cat1_group'] == cat1]
        
        if group_a.empty or group_b.empty:
            continue
        
        # 在分组内匹配（性能提升：从 N×M 降为 n×m，其中 n,m << N,M）
        matches_in_group = _core_fuzzy_match(group_a, group_b, name_a, name_b, soft_match_params, cross_encoder)
        
        if not matches_in_group.empty:
            all_soft_matches.append(matches_in_group)
            matched_indices_a.update(matches_in_group[f'index_{name_a}'].tolist())
            matched_indices_b.update(matches_in_group[f'index_{name_b}'].tolist())
    
    # === 🔧 方案2C：智能混合策略 - 三级分类补充匹配 ===
    enable_cat3_fallback = os.environ.get('ENABLE_CAT3_FALLBACK', '1') == '1'
    
    if enable_cat3_fallback and '三级分类' in df_a.columns and '三级分类' in df_b.columns:
        # 找出未匹配的商品
        unmatched_a = df_a[~df_a.index.isin(matched_indices_a)].copy()
        unmatched_b = df_b[~df_b.index.isin(matched_indices_b)].copy()
        
        # 智能筛选：只对可能被错误分类的商品进行三级分类匹配
        def is_likely_misclassified(row):
            """判断商品是否可能被错误分类"""
            name = str(row.get('商品名称', '')).lower()
            price = pd.to_numeric(row.get('原价', 0), errors='coerce')
            
            # 条件1: 包含知名品牌关键词
            brand_keywords = ['可口可乐', '百事', '康师傅', '统一', '雀巢', '伊利', '蒙牛', '农夫山泉', 
                            '娃哈哈', '达利园', '奥利奥', '乐事', '卫龙', '三只松鼠', '良品铺子']
            has_brand = any(brand in name for brand in brand_keywords)
            
            # 条件2: 价格在典型范围（排除异常商品）
            normal_price = 1 <= price <= 100 if pd.notna(price) else True
            
            # 条件3: 商品名称长度适中（排除描述过短或过长的异常数据）
            name_len_ok = 5 <= len(name) <= 100
            
            return (has_brand or normal_price) and name_len_ok
        
        if not unmatched_a.empty and not unmatched_b.empty:
            candidates_a = unmatched_a[unmatched_a.apply(is_likely_misclassified, axis=1)]
            candidates_b = unmatched_b[unmatched_b.apply(is_likely_misclassified, axis=1)]
            
            if not candidates_a.empty and not candidates_b.empty:
                # 按三级分类分组
                candidates_a['cat3_group'] = candidates_a['三级分类'].astype(str)
                candidates_b['cat3_group'] = candidates_b['三级分类'].astype(str)
                
                common_cat3 = set(candidates_a['cat3_group']) & set(candidates_b['cat3_group'])
                
                if common_cat3:
                    logging.info(f"🔧 三级分类补充匹配：找到 {len(common_cat3)} 个共同三级分类，候选商品 A:{len(candidates_a)} B:{len(candidates_b)}")
                    
                    cat3_matches = []
                    for cat3 in tqdm(common_cat3, desc="   三级分类补充匹配", dynamic_ncols=True, mininterval=1.0, ascii=True, file=sys.stdout):
                        group_a_cat3 = candidates_a[candidates_a['cat3_group'] == cat3]
                        group_b_cat3 = candidates_b[candidates_b['cat3_group'] == cat3]
                        
                        if group_a_cat3.empty or group_b_cat3.empty:
                            continue
                        
                        # 使用相同的匹配参数，但不强制一级分类
                        cat3_params = soft_match_params.copy()
                        cat3_params['require_category_match'] = False  # 允许一级分类不同
                        cat3_params['require_cat3_match'] = True  # 强制三级分类相同
                        
                        matches_cat3 = _core_fuzzy_match(group_a_cat3, group_b_cat3, name_a, name_b, cat3_params, cross_encoder)
                        
                        if not matches_cat3.empty:
                            cat3_matches.append(matches_cat3)
                    
                    if cat3_matches:
                        cat3_matches_df = pd.concat(cat3_matches, ignore_index=True)
                        cat3_matches_df = cat3_matches_df.drop(columns=[f'index_{name_a}', f'index_{name_b}'], errors='ignore')
                        all_soft_matches.append(cat3_matches_df)
                        logging.info(f"   ✅ 三级分类补充匹配成功：新增 {len(cat3_matches_df)} 条跨一级分类匹配")
                
                candidates_a.drop(columns=['cat3_group'], errors='ignore', inplace=True)
                candidates_b.drop(columns=['cat3_group'], errors='ignore', inplace=True)
    
    if not all_soft_matches:
        # 清理辅助列
        df_a.drop(columns=['cat1_group'], errors='ignore', inplace=True)
        df_b.drop(columns=['cat1_group'], errors='ignore', inplace=True)
        return pd.DataFrame()
    
    final_soft_matches = pd.concat(all_soft_matches, ignore_index=True)
    final_soft_matches = final_soft_matches.drop(columns=[f'index_{name_a}', f'index_{name_b}'], errors='ignore')
    
    # 清理辅助列
    df_a.drop(columns=['cat1_group'], errors='ignore', inplace=True)
    df_b.drop(columns=['cat1_group'], errors='ignore', inplace=True)
    
    return final_soft_matches


def _perform_soft_match_without_grouping(df_a: pd.DataFrame, df_b: pd.DataFrame, name_a: str, name_b: str, cross_encoder=None, cfg=None) -> pd.DataFrame:
    """
    兜底方案：不分组的全量软匹配（性能较差，仅在缺少分类列时使用）
    """
    adaptive_threshold = 0.5
    if cfg:
        adaptive_threshold = get_adaptive_threshold(cfg.SENTENCE_BERT_MODEL, cfg, match_type='soft')

    soft_match_params = {
        "price_similarity_percent": 20,
        "composite_threshold": adaptive_threshold,
        "text_weight": 0.5,
        "brand_weight": 0.3,
        "category_weight": 0.1,
        "specs_weight": 0.1,
        "candidates_to_check": int(os.environ.get('MATCH_TOPK_SOFT', '100')),
        "require_category_match": True,
        "require_cat3_match": True,
    }
    soft_match_params = override_match_params(soft_match_params, phase='SOFT')

    soft_matches = _core_fuzzy_match(df_a, df_b, name_a, name_b, soft_match_params, cross_encoder)
    
    if not soft_matches.empty:
        soft_matches = soft_matches.drop(columns=[f'index_{name_a}', f'index_{name_b}'], errors='ignore')

    return soft_matches


def _core_fuzzy_match(df_a: pd.DataFrame, df_b: pd.DataFrame, name_a: str, name_b: str, params: dict, cross_encoder=None) -> pd.DataFrame:
    """
    模糊匹配的核心计算逻辑，被硬匹配和软匹配共同调用。
    """
    if df_a.empty or df_b.empty:
        return pd.DataFrame()

    k = params.get('candidates_to_check', 50)
    matched_products = []

    # 预处理 B 侧数值列
    df_b_temp = df_b.copy()
    df_b_temp['原价_numeric'] = pd.to_numeric(df_b_temp['原价'], errors='coerce')

    use_simple = SIMPLE_FALLBACK or (df_a['vector'].iloc[0].shape == (1,))
    if not use_simple:
        # 计算向量相似度矩阵并选取候选
        df_a_vectors = np.array(df_a['vector'].tolist())
        df_b_vectors = np.array(df_b['vector'].tolist())
        sim_matrix = cosine_similarity(df_a_vectors, df_b_vectors)
        top_k_indices = np.argsort(sim_matrix, axis=1)[:, -k:]

    for i in tqdm(range(len(df_a)), desc=f"核心模糊匹配 ({name_a} vs {name_b})", leave=False, dynamic_ncols=True, mininterval=0.5, ascii=True, file=sys.stdout):
        row_a = df_a.iloc[i]
        price_a = pd.to_numeric(row_a['原价'], errors='coerce')
        if pd.isna(price_a) or price_a == 0:
            continue

        price_min = price_a * (1 - params['price_similarity_percent'] / 100)
        price_max = price_a * (1 + params['price_similarity_percent'] / 100)

        best_overall_score = -1
        best_match_row_b = None

        candidate_pairs = []
        valid_candidates = []

        if use_simple:
            # 简化模式：先用价格+（可选）分类筛选，再用 difflib 文本相似度取 Top-K
            mask = df_b_temp['原价_numeric'].between(price_min, price_max)
            if params.get("require_category_match", False):
                mask &= (df_b_temp['一级分类'].astype(str) == str(row_a.get('一级分类', '')))
            if params.get('require_cat3_match', False):
                mask &= (df_b_temp['三级分类'].astype(str) == str(row_a.get('三级分类','')))
            cand_df = df_b_temp[mask]
            if cand_df.empty:
                continue
            # 计算文本相似度（difflib）
            a_text = f"{row_a.get('cleaned_商品名称','')} {row_a.get('cleaned_一级分类','')} {row_a.get('cleaned_三级分类','')}"
            scores = []
            cand_rows = []
            for _, rb in cand_df.iterrows():
                b_text = f"{rb.get('cleaned_商品名称','')} {rb.get('cleaned_一级分类','')} {rb.get('cleaned_三级分类','')}"
                try:
                    s = difflib.SequenceMatcher(None, a_text, b_text).ratio()
                except Exception:
                    s = 0.0
                scores.append(s)
                cand_rows.append(rb)
            if not scores:
                continue
            # 选 Top-K
            order = np.argsort(np.array(scores))[-k:]
            valid_candidates = [cand_rows[idx] for idx in order]
            candidate_pairs = [[row_a['商品名称'], r['商品名称']] for r in valid_candidates]
        else:
            # 精排：对粗筛出的候选商品进行详细打分
            for b_idx in top_k_indices[i]:
                row_b = df_b_temp.iloc[b_idx]
                # 价格过滤
                if not (price_min <= row_b['原价_numeric'] <= price_max):
                    continue
                # 新增：强制分类过滤（如果参数要求）
                if params.get("require_category_match", False):
                    cat1_a = str(row_a.get('一级分类', '')).strip()
                    cat1_b = str(row_b.get('一级分类', '')).strip()
                    # 要求两侧分类都非空且完全匹配
                    if not cat1_a or not cat1_b or cat1_a != cat1_b:
                        continue
                candidate_pairs.append([row_a['商品名称'], row_b['商品名称']])
                valid_candidates.append(row_b)

        # 如果要求品牌/三级分类/规格一致，则提前过滤候选
        if params.get('require_brand_match', False):
            def _brand_ok(ra, rb):
                ba = str(ra.get('standardized_brand') or '').strip().lower()
                bb = str(rb.get('standardized_brand') or '').strip().lower()
                if not ba or not bb or ba == '其他' or bb == '其他':
                    return False
                return ba == bb
            new_pairs = []
            new_valid = []
            for pair, rb in zip(candidate_pairs, valid_candidates):
                if _brand_ok(row_a, rb):
                    new_pairs.append(pair)
                    new_valid.append(rb)
            candidate_pairs, valid_candidates = new_pairs, new_valid

        if params.get('require_cat3_match', False) and candidate_pairs:
            new_pairs = []
            new_valid = []
            cat3a = str(row_a.get('三级分类',''))
            for pair, rb in zip(candidate_pairs, valid_candidates):
                if str(rb.get('三级分类','')) == cat3a:
                    new_pairs.append(pair)
                    new_valid.append(rb)
            candidate_pairs, valid_candidates = new_pairs, new_valid

        if params.get('require_specs_match', False) and candidate_pairs:
            new_pairs = []
            new_valid = []
            sa = str(row_a.get('specs') or '').strip()
            for pair, rb in zip(candidate_pairs, valid_candidates):
                sb = str(rb.get('specs') or '').strip()
                if sa and sb and sa == sb:
                    new_pairs.append(pair)
                    new_valid.append(rb)
            candidate_pairs, valid_candidates = new_pairs, new_valid

        # 最小分词重叠（基于 cleaned_商品名称），用于过滤语义完全不相干的条目
        min_overlap = int(params.get('min_token_overlap', 0) or 0)
        if min_overlap > 0 and candidate_pairs:
            a_tokens = set(tokenize_text(row_a.get('cleaned_商品名称','')))
            new_pairs = []
            new_valid = []
            for pair, rb in zip(candidate_pairs, valid_candidates):
                b_tokens = set(tokenize_text(rb.get('cleaned_商品名称','')))
                if len(a_tokens & b_tokens) >= min_overlap:
                    new_pairs.append(pair)
                    new_valid.append(rb)
            candidate_pairs, valid_candidates = new_pairs, new_valid

        if not candidate_pairs:
            continue

        # 使用Cross-Encoder进行精排打分
        if cross_encoder and not use_simple:
            raw_scores = cross_encoder.predict(candidate_pairs, show_progress_bar=False)
            text_scores = 1 / (1 + np.exp(-np.array(raw_scores))) # Sigmoid归一化
        else:
            # 简化模式或无 CrossEncoder：
            if use_simple:
                # 已按 difflib 选出候选，这里再次取 difflib 分数作为文本相似度
                a_text = f"{row_a.get('cleaned_商品名称','')} {row_a.get('cleaned_一级分类','')} {row_a.get('cleaned_三级分类','')}"
                text_scores = []
                for row_b in valid_candidates:
                    b_text = f"{row_b.get('cleaned_商品名称','')} {row_b.get('cleaned_一级分类','')} {row_b.get('cleaned_三级分类','')}"
                    try:
                        text_scores.append(difflib.SequenceMatcher(None, a_text, b_text).ratio())
                    except Exception:
                        text_scores.append(0.0)
            else:
                # 使用向量余弦相似度
                text_scores = [sim_matrix[i, df_b.index.get_loc(row.name)] for row in valid_candidates]

        for idx, row_b in enumerate(valid_candidates):
            text_sim = text_scores[idx]
            
            # 计算品牌、分类、规格等特征的相似度
            brand_sim, cat_sim, specs_sim, _ = calculate_feature_similarity(row_a, row_b)

            # 计算综合得分（对品牌完全一致给予轻微加成）
            brand_bonus = 0.05 if (params.get('require_brand_match', False) and brand_sim == 1) else 0.0
            composite_score = (
                text_sim * params.get('text_weight', 0.6) +
                brand_sim * params.get('brand_weight', 0.2) +
                cat_sim * params.get('category_weight', 0.1) +
                specs_sim * params.get('specs_weight', 0.1) +
                brand_bonus
            )

            if composite_score > best_overall_score and composite_score >= params['composite_threshold']:
                best_overall_score = composite_score
                best_match_row_b = row_b

        if best_match_row_b is not None:
            match_info = {}
            for col in df_a.columns.difference(['vector', 'category_id']):
                match_info[f"{col}_{name_a}"] = row_a[col]
            for col in df_b.columns.difference(['vector', 'category_id', '原价_numeric']):
                match_info[f"{col}_{name_b}"] = best_match_row_b[col]
            
            match_info['composite_similarity_score'] = best_overall_score
            # 保存原始索引，用于后续从未匹配列表中排除
            match_info[f'index_{name_a}'] = row_a.name
            match_info[f'index_{name_b}'] = best_match_row_b.name
            matched_products.append(match_info)

    return pd.DataFrame(matched_products)

class DifferentialMatchConfig:
    """差异品匹配动态权重配置"""
    
    # 是否强制要求三级分类一致（默认False，允许三级分类不同但会标记警告）
    REQUIRE_CAT3_MATCH = True  # 🔧 开启三级分类强制匹配，与软分类阶段保持一致
    
    # 品类权重配置
    CATEGORY_WEIGHTS = {
        # 差异品匹配：各品类阈值配置（优化：提高下限，减少不相关匹配）
        # 饮料类：品牌多，名称相似，价格敏感
        '饮料': {
            'similarity_min': 0.42,  # 🔧 提高下限 0.35→0.42
            'similarity_max': 0.65,
            'price_tolerance': 0.35,
            'description': '品牌众多，价格敏感'
        },
        # 零食类：品类繁杂，规格多样
        '休闲食品': {
            'similarity_min': 0.40,  # 🔧 提高下限 0.30→0.40
            'similarity_max': 0.62,
            'price_tolerance': 0.40,
            'description': '品类繁杂，规格多样'
        },
        '粮油调味': {
            'similarity_min': 0.42,  # 🔧 提高下限 0.35→0.42
            'similarity_max': 0.65,
            'price_tolerance': 0.50,
            'description': '品牌差异大，价格范围广'
        },
        '方便食品': {
            'similarity_min': 0.40,  # 🔧 提高下限 0.30→0.40
            'similarity_max': 0.62,
            'price_tolerance': 0.45,
            'description': '品类多样，规格差异大'
        },
        '乳品烘焙': {
            'similarity_min': 0.42,  # 🔧 提高下限 0.35→0.42
            'similarity_max': 0.65,
            'price_tolerance': 0.40,
            'description': '品牌集中，价格稳定'
        },
        # 日用品类：品牌差异大，功能相似即可
        '个人护理': {
            'similarity_min': 0.40,  # 🔧 提高下限 0.32→0.40
            'similarity_max': 0.62,
            'price_tolerance': 0.40,
            'description': '功能相似即可，品牌差异大'
        },
        '家居用品': {
            'similarity_min': 0.40,  # 🔧 提高下限 0.30→0.40
            'similarity_max': 0.62,
            'price_tolerance': 0.40,
            'description': '功能导向，价格差异大'
        },
        '清洁用品': {
            'similarity_min': 0.40,  # 🔧 提高下限 0.32→0.40
            'similarity_max': 0.62,
            'price_tolerance': 0.45,
            'description': '功能主导，品牌多样'
        },
        # 生鲜类：规格和价格都很敏感
        '水果': {
            'similarity_min': 0.45,  # 🔧 提高下限 0.40→0.45
            'similarity_max': 0.70,
            'price_tolerance': 0.50,
            'description': '季节性强，价格波动大'
        },
        '蔬菜': {
            'similarity_min': 0.45,  # 🔧 提高下限 0.40→0.45
            'similarity_max': 0.70,
            'price_tolerance': 0.50,
            'description': '季节性强，价格波动大'
        },
        '肉禽蛋': {
            'similarity_min': 0.42,  # 🔧 提高下限 0.38→0.42
            'similarity_max': 0.68,
            'price_tolerance': 0.45,
            'description': '品类明确，价格敏感'
        },
        '海鲜水产': {
            'similarity_min': 0.42,  # 🔧 提高下限 0.35→0.42
            'similarity_max': 0.65,
            'price_tolerance': 0.50,
            'description': '规格差异大，价格波动'
        },
        # 默认配置
        'default': {
            'similarity_min': 0.40,  # 🔧 提高下限 0.32→0.40
            'similarity_max': 0.65,
            'price_tolerance': 0.40,
            'description': '未分类商品默认策略'
        }
    }
    
    @classmethod
    def get_config(cls, category):
        """
        获取品类配置
        支持模糊匹配：如果精确匹配失败，尝试包含匹配
        """
        # 精确匹配
        if category in cls.CATEGORY_WEIGHTS:
            return cls.CATEGORY_WEIGHTS[category]
        
        # 模糊匹配（包含关系）
        for key, config in cls.CATEGORY_WEIGHTS.items():
            if key in str(category) or str(category) in key:
                return config
        
        # 返回默认配置
        return cls.CATEGORY_WEIGHTS['default']
    
    @classmethod
    def get_config_info(cls, category):
        """获取配置说明"""
        config = cls.get_config(category)
        return f"相似度[{config['similarity_min']}-{config['similarity_max']}], 价格±{int(config['price_tolerance']*100)}%"

def deduplicate_unique_products(df, store_name):
    """
    对独有商品按商品名称去重
    
    Args:
        df: 独有商品DataFrame
        store_name: 店铺名称
    
    Returns:
        去重后的DataFrame，包含SKU数量统计
    """
    if df.empty:
        return df
    
    # 按商品名称分组统计
    agg_dict = {
        '售价': 'first',  # 保留第一条记录的售价
        '原价': 'first',
        '美团一级分类': 'first',
        '美团三级分类': 'first',
        '条码': lambda x: ', '.join([str(b) for b in x.dropna().unique() if str(b) != 'nan']),  # 合并条码
        '库存': 'sum',  # 库存求和
        '月售': 'sum',  # 月售求和
    }
    
    # ⭐关键：保留vector列供差异品分析使用
    if 'vector' in df.columns:
        agg_dict['vector'] = lambda x: x.iloc[0]  # 保留第一条记录的向量（保持原格式）
    
    grouped = df.groupby('商品名称', as_index=False).agg(agg_dict)
    
    # 添加SKU数量列
    sku_counts = df.groupby('商品名称').size().reset_index(name='SKU数量')
    grouped = grouped.merge(sku_counts, on='商品名称', how='left')
    
    # 重新排序列
    cols_order = ['商品名称', 'SKU数量', '美团一级分类', '美团三级分类', '售价', '原价', '库存', '月售', '条码']
    cols_order = [c for c in cols_order if c in grouped.columns]
    other_cols = [c for c in grouped.columns if c not in cols_order]
    grouped = grouped[cols_order + other_cols]
    
    # 按分类和售价排序
    if '美团一级分类' in grouped.columns:
        grouped = grouped.sort_values(['美团一级分类', '售价'], ascending=[True, False])
    
    print(f"   去重前: {len(df)} 条，去重后: {len(grouped)} 条独有商品")
    return grouped

def find_differential_products(df_a_unique, df_b_unique, name_a, name_b, cfg=None):
    """
    差异品分析：在独有商品中找同分类、价格相似但不完全相同的商品
    
    Args:
        df_a_unique: 本店独有商品
        df_b_unique: 竞对独有商品
        name_a: 本店名称
        name_b: 竞对名称
        cfg: 配置对象（用于获取向量模型）
    
    Returns:
        差异品对比DataFrame
    """
    if df_a_unique.empty or df_b_unique.empty:
        return pd.DataFrame()
    
    print(f"\n🔍 开始差异品分析...")
    print(f"   本店独有: {len(df_a_unique)} 条，竞对独有: {len(df_b_unique)} 条")
    print(f"   匹配模式: {'✅一对一最佳匹配' if True else '多对多'} | 三级分类: {'⚠️强制一致' if DifferentialMatchConfig.REQUIRE_CAT3_MATCH else '✅允许不同(标记警告)'}")
    
    differential_matches = []
    
    # 确保必要的列存在
    required_cols = ['商品名称', '售价', '美团一级分类', 'vector']
    for col in required_cols:
        if col not in df_a_unique.columns or col not in df_b_unique.columns:
            print(f"   ⚠️ 缺少必要列 '{col}'，跳过差异品分析")
            return pd.DataFrame()
    
    # 诊断信息：检查共同分类
    cats_a = set(df_a_unique['美团一级分类'].dropna().unique())
    cats_b = set(df_b_unique['美团一级分类'].dropna().unique())
    common_cats = cats_a & cats_b
    print(f"   一级分类: A店{len(cats_a)}个, B店{len(cats_b)}个, 共同{len(common_cats)}个")
    
    # 检查三级分类覆盖
    if '美团三级分类' in df_a_unique.columns and '美团三级分类' in df_b_unique.columns:
        cats3_a = set(df_a_unique['美团三级分类'].dropna().unique())
        cats3_b = set(df_b_unique['美团三级分类'].dropna().unique())
        common_cats3 = cats3_a & cats3_b
        print(f"   三级分类: A店{len(cats3_a)}个, B店{len(cats3_b)}个, 共同{len(common_cats3)}个")
    
    if not common_cats:
        print(f"   ⚠️ 没有共同的一级分类，无法匹配差异品")
        return pd.DataFrame()
    
    # 智能价格选择：优先使用原价，原价无效则使用售价
    df_a_unique = df_a_unique.copy()
    df_b_unique = df_b_unique.copy()
    
    # 转换原价和售价为数值（使用.get()安全获取列，避免KeyError）
    if '原价' in df_a_unique.columns:
        df_a_unique['原价_numeric'] = pd.to_numeric(df_a_unique['原价'], errors='coerce')
    else:
        df_a_unique['原价_numeric'] = pd.NA
    df_a_unique['售价_numeric'] = pd.to_numeric(df_a_unique['售价'], errors='coerce')
    
    if '原价' in df_b_unique.columns:
        df_b_unique['原价_numeric'] = pd.to_numeric(df_b_unique['原价'], errors='coerce')
    else:
        df_b_unique['原价_numeric'] = pd.NA
    df_b_unique['售价_numeric'] = pd.to_numeric(df_b_unique['售价'], errors='coerce')
    
    # 智能价格选择：原价 > 0 优先，否则用售价
    df_a_unique['对比价格'] = df_a_unique.apply(
        lambda row: row['原价_numeric'] if (pd.notna(row['原价_numeric']) and row['原价_numeric'] > 0) else row['售价_numeric'],
        axis=1
    )
    df_a_unique['价格来源'] = df_a_unique.apply(
        lambda row: '原价' if (pd.notna(row['原价_numeric']) and row['原价_numeric'] > 0) else '售价',
        axis=1
    )
    
    df_b_unique['对比价格'] = df_b_unique.apply(
        lambda row: row['原价_numeric'] if (pd.notna(row['原价_numeric']) and row['原价_numeric'] > 0) else row['售价_numeric'],
        axis=1
    )
    df_b_unique['价格来源'] = df_b_unique.apply(
        lambda row: '原价' if (pd.notna(row['原价_numeric']) and row['原价_numeric'] > 0) else '售价',
        axis=1
    )
    
    # 按一级分类分组匹配
    categories_a = df_a_unique['美团一级分类'].unique()
    matched_count = 0
    
    # 调试：检查价格数据
    valid_price_a = df_a_unique['对比价格'].notna() & (df_a_unique['对比价格'] > 0)
    valid_price_b = df_b_unique['对比价格'].notna() & (df_b_unique['对比价格'] > 0)
    orig_count_a = (df_a_unique['价格来源'] == '原价').sum()
    orig_count_b = (df_b_unique['价格来源'] == '原价').sum()
    print(f"   💰 价格检查: A店有效价格 {valid_price_a.sum()}/{len(df_a_unique)} (原价{orig_count_a}, 售价{valid_price_a.sum()-orig_count_a})")
    print(f"   💰 价格检查: B店有效价格 {valid_price_b.sum()}/{len(df_b_unique)} (原价{orig_count_b}, 售价{valid_price_b.sum()-orig_count_b})")
    
    print(f"   开始分类匹配（共 {len(common_cats)} 个共同分类）...")
    
    # 导入进度条
    from tqdm import tqdm
    
    # 使用进度条遍历分类
    for idx, category in enumerate(tqdm(categories_a, desc="   🔍 差异品分析", ncols=100), 1):
        # 获取该分类的动态权重配置
        config = DifferentialMatchConfig.get_config(category)
        config_info = DifferentialMatchConfig.get_config_info(category)
        
        # 🔧 调试：输出前3个分类的配置信息
        if idx <= 3:
            tqdm.write(f"   📋 [{category}] 配置: {config_info} (相似度范围: {config['similarity_min']:.2f}-{config['similarity_max']:.2f})")
        
        # 筛选同分类商品
        df_a_cat = df_a_unique[df_a_unique['美团一级分类'] == category].copy()
        df_b_cat = df_b_unique[df_b_unique['美团一级分类'] == category].copy()
        
        # 调试：检查对比价格列是否存在
        if idx <= 3 and ('对比价格' not in df_a_cat.columns or '对比价格' not in df_b_cat.columns):
            tqdm.write(f"   ⚠️ [{category}] 缺少对比价格列!")
            tqdm.write(f"       A列: {[c for c in df_a_cat.columns if '价格' in c or '价' in c]}")
            tqdm.write(f"       B列: {[c for c in df_b_cat.columns if '价格' in c or '价' in c]}")
        
        if df_a_cat.empty or df_b_cat.empty:
            continue
        
        # 计算向量相似度
        try:
            from sklearn.metrics.pairwise import cosine_similarity
            import numpy as np
            
            # 诊断：检查vector格式（仅前3个分类）
            if idx <= 3:
                sample_vec_a = df_a_cat['vector'].iloc[0] if len(df_a_cat) > 0 else None
                sample_vec_b = df_b_cat['vector'].iloc[0] if len(df_b_cat) > 0 else None
                tqdm.write(f"       🔍 Vector格式: A类型={type(sample_vec_a).__name__}, B类型={type(sample_vec_b).__name__}")
                if sample_vec_a is not None:
                    if isinstance(sample_vec_a, (list, np.ndarray)):
                        tqdm.write(f"       🔍 Vector长度: A={len(sample_vec_a)}, 首5值={sample_vec_a[:5] if len(sample_vec_a)>=5 else sample_vec_a}")
            
            vectors_a = np.array(df_a_cat['vector'].tolist())
            vectors_b = np.array(df_b_cat['vector'].tolist())
            sim_matrix = cosine_similarity(vectors_a, vectors_b)
        except Exception as e:
            if idx <= 3:
                import traceback
                tqdm.write(f"   ⚠️ [{category}] 计算相似度失败: {e}")
                tqdm.write(f"       详细错误: {traceback.format_exc()[:200]}")
            continue
        
        category_matches = 0
        debug_info = {
            'total_a': len(df_a_cat),
            'total_b': len(df_b_cat),
            'valid_price_a': 0,
            'valid_price_b': 0,
            'similarity_in_range': 0,
            'price_in_range': 0,
            'cat3_mismatch': 0,
            'final_matches': 0
        }
        
        # 用于记录每个商品的最佳匹配（一对一）
        best_matches_a = {}  # {idx_a: (idx_b, similarity, match_record)}
        
        # 遍历本店商品，找差异品
        for i, row_a in df_a_cat.iterrows():
            price_a = row_a['对比价格']
            if pd.isna(price_a) or price_a <= 0:
                continue
            
            debug_info['valid_price_a'] += 1
            
            # 使用动态价格范围
            price_min = price_a * (1 - config['price_tolerance'])
            price_max = price_a * (1 + config['price_tolerance'])
            
            # 获取该商品在相似度矩阵中的索引
            idx_a = df_a_cat.index.get_loc(i)
            similarities = sim_matrix[idx_a]
            
            # 找到相似度在动态范围内且价格相似的商品
            for j, row_b in df_b_cat.iterrows():
                idx_b = df_b_cat.index.get_loc(j)
                similarity = similarities[idx_b]
                
                # 使用动态相似度范围检查
                if similarity < config['similarity_min'] or similarity > config['similarity_max']:
                    continue
                
                debug_info['similarity_in_range'] += 1
                
                # 调试：检查B店价格数据
                price_b = row_b.get('对比价格', None)
                if price_b is None or pd.isna(price_b) or price_b <= 0:
                    # 第一次遇到时打印调试信息
                    if debug_info['similarity_in_range'] == 1 and idx <= 3:
                        tqdm.write(f"       ⚠️ 调试: B店row缺少有效价格 - 对比价格={price_b}, 原价={row_b.get('原价_numeric')}, 售价={row_b.get('售价_numeric')}")
                    continue
                
                debug_info['valid_price_b'] += 1
                
                # 价格范围检查
                if price_b < price_min or price_b > price_max:
                    continue
                
                debug_info['price_in_range'] += 1
                
                # 三级分类检查：优先匹配相同三级分类
                cat3_a = row_a.get('美团三级分类', '')
                cat3_b = row_b.get('美团三级分类', '')
                cat3_match = False
                cat3_warning = ''
                
                if cat3_a and cat3_b and str(cat3_a) != 'nan' and str(cat3_b) != 'nan':
                    if cat3_a == cat3_b:
                        cat3_match = True
                        cat3_warning = ''
                    else:
                        # 三级分类不同，但允许匹配（可能是分类错误）
                        cat3_match = False
                        cat3_warning = f'⚠️三级分类不同({cat3_a}≠{cat3_b})'
                        debug_info['cat3_mismatch'] += 1
                        # ⚠️ 如果启用严格三级分类匹配，跳过不一致的商品
                        if DifferentialMatchConfig.REQUIRE_CAT3_MATCH:
                            continue  # 跳过三级分类不一致的商品
                
                # 构建差异品匹配记录 - 完整的ABAB格式
                price_diff_pct = ((price_b - price_a) / price_a) * 100
                
                # 基础字段 - ABAB格式
                match_record = {
                    f'商品名称_{name_a}': row_a['商品名称'],
                    f'商品名称_{name_b}': row_b['商品名称'],
                    f'美团一级分类_{name_a}': category,
                    f'美团一级分类_{name_b}': category,
                }
                
                # 三级分类 - ABAB格式
                if '美团三级分类' in row_a.index and '美团三级分类' in row_b.index:
                    match_record[f'美团三级分类_{name_a}'] = row_a.get('美团三级分类', '')
                    match_record[f'美团三级分类_{name_b}'] = row_b.get('美团三级分类', '')
                
                # 原价 - ABAB格式
                match_record[f'原价_{name_a}'] = row_a.get('原价_numeric', '')
                match_record[f'原价_{name_b}'] = row_b.get('原价_numeric', '')
                
                # 售价 - ABAB格式
                match_record[f'售价_{name_a}'] = row_a.get('售价_numeric', '')
                match_record[f'售价_{name_b}'] = row_b.get('售价_numeric', '')
                
                # 月售 - ABAB格式
                if '月售' in row_a.index and '月售' in row_b.index:
                    match_record[f'月售_{name_a}'] = row_a.get('月售', 0)
                    match_record[f'月售_{name_b}'] = row_b.get('月售', 0)
                
                # 库存 - ABAB格式
                if '库存' in row_a.index and '库存' in row_b.index:
                    match_record[f'库存_{name_a}'] = row_a.get('库存', 0)
                    match_record[f'库存_{name_b}'] = row_b.get('库存', 0)
                
                # 分析字段（放在最后）
                match_record[f'对比价格来源_{name_a}'] = row_a['价格来源']
                match_record[f'对比价格来源_{name_b}'] = row_b['价格来源']
                match_record['price_diff_pct'] = round(price_diff_pct, 1)
                match_record['similarity_score'] = round(similarity, 3)
                match_record['差异分析'] = '同类替代品' if similarity > 0.45 else '同类相关品'
                match_record['分类一致性'] = '三级分类一致' if cat3_match else cat3_warning if cat3_warning else '无三级分类'
                
                # ⭐ 一对一最佳匹配：只保留每个A店商品相似度最高的那个B店商品
                if i not in best_matches_a:
                    best_matches_a[i] = (j, similarity, match_record)
                else:
                    # 如果已有匹配，比较相似度，保留更好的
                    _, prev_sim, _ = best_matches_a[i]
                    if similarity > prev_sim:
                        best_matches_a[i] = (j, similarity, match_record)
        
        # 将最佳匹配添加到结果中
        for idx_a, (idx_b, sim, match_record) in best_matches_a.items():
            differential_matches.append(match_record)
            category_matches += 1
            debug_info['final_matches'] += 1
        
        # 每个分类处理后显示进度
        if category_matches > 0:
            matched_count += category_matches
            cat3_mismatch_pct = (debug_info['cat3_mismatch'] / category_matches * 100) if category_matches > 0 else 0
            tqdm.write(f"   ✅ [{category}] 找到 {category_matches} 对差异品 ({config_info}){' | 三级分类不一致:'+str(debug_info['cat3_mismatch'])+'对' if debug_info['cat3_mismatch'] > 0 else ''}")
        elif idx <= 5:  # 前5个显示详细调试（增加到5个）
            tqdm.write(f"   ⚪ [{category}] 0对 ({config_info})")
            tqdm.write(f"       🔍 漏斗: A商品{debug_info['total_a']} → A有效价格{debug_info['valid_price_a']} → 相似度符合{debug_info['similarity_in_range']} → B有效价格{debug_info['valid_price_b']} → 价格符合{debug_info['price_in_range']} → 三级分类检查后{debug_info['price_in_range']-debug_info['cat3_mismatch']} → 一对一最佳匹配{debug_info['final_matches']}")
            
            # 额外诊断：显示实际相似度分布（仅前3个分类）
            if idx <= 3 and len(sim_matrix) > 0:
                sim_flat = sim_matrix.flatten()
                sim_in_range = sim_flat[(sim_flat >= config['similarity_min']) & (sim_flat <= config['similarity_max'])]
                tqdm.write(f"       📊 相似度: 最大{sim_flat.max():.3f}, 均值{sim_flat.mean():.3f}, 最小{sim_flat.min():.3f}, 在范围内{len(sim_in_range)}/{len(sim_flat)}")
    
    if not differential_matches:
        print(f"   ❌ 未找到符合条件的差异品")
        print(f"\n   � 详细诊断:")
        print(f"      • 共同分类数: {len(common_cats)}")
        print(f"      • A店有效价格: {valid_price_a.sum()}/{len(df_a_unique)}")
        print(f"      • B店有效价格: {valid_price_b.sum()}/{len(df_b_unique)}")
        print(f"      • vector列存在: A={('vector' in df_a_unique.columns)}, B={('vector' in df_b_unique.columns)}")
        print(f"\n   �💡 可能原因:")
        print(f"      1. ⭐去重后缺少vector列（已修复，请重新运行）")
        print(f"      2. 价格差异超出各品类动态容差范围（饮料±35%, 休闲食品±40%, 生鲜±50%等）")
        print(f"      3. 相似度不在各品类动态范围内（如饮料0.30-0.60, 休闲食品0.25-0.60等）")
        print(f"      4. 一级分类不匹配（需要两店有共同的分类）")
        print(f"      5. 商品价格缺失或为0")
        print(f"\n   🔧 建议操作:")
        print(f"      → 重新运行完整比价分析（已修复vector列保留问题）")
        print(f"      → 如仍然0匹配，可临时放宽阈值测试")
        return pd.DataFrame()
    
    df_differential = pd.DataFrame(differential_matches)
    
    # 统计三级分类匹配情况
    cat3_mismatch = df_differential[df_differential['分类一致性'].str.contains('⚠️', na=False)]
    if len(cat3_mismatch) > 0:
        print(f"   ⚠️  发现 {len(cat3_mismatch)} 对商品三级分类不一致（可能存在分类错误）")
    
    # 按相似度降序排序
    df_differential = df_differential.sort_values('similarity_score', ascending=False)
    
    print(f"   ✅ 找到 {len(df_differential)} 对差异品匹配")
    return df_differential

def analyze_category_gaps(df_a_unique, df_b_unique, name_a, name_b):
    """
    品类缺口分析：找出竞对有但本店没有的细分品类（商品明细展开）
    
    Returns:
        品类缺口分析DataFrame（每个商品一行）
    """
    if df_a_unique.empty or df_b_unique.empty:
        return pd.DataFrame()
    
    print(f"\n📊 开始品类缺口分析...")
    
    # 统计各店的分类组合
    if '美团三级分类' in df_a_unique.columns and '美团三级分类' in df_b_unique.columns:
        # 按一级+三级组合分析
        df_a_unique['分类组合'] = df_a_unique['美团一级分类'].astype(str) + ' > ' + df_a_unique['美团三级分类'].astype(str)
        df_b_unique['分类组合'] = df_b_unique['美团一级分类'].astype(str) + ' > ' + df_b_unique['美团三级分类'].astype(str)
    else:
        # 只按一级分类分析
        df_a_unique['分类组合'] = df_a_unique['美团一级分类'].astype(str)
        df_b_unique['分类组合'] = df_b_unique['美团一级分类'].astype(str)
    
    # 找出竞对独有的分类
    categories_a = set(df_a_unique['分类组合'].unique())
    categories_b = set(df_b_unique['分类组合'].unique())
    gap_categories = categories_b - categories_a
    
    if not gap_categories:
        print(f"   本店品类覆盖完整，无明显缺口")
        return pd.DataFrame()
    
    # 🔧 方案A：展开所有商品明细
    gap_products = []
    total_gap_products = 0
    
    for category in sorted(gap_categories):
        cat_products = df_b_unique[df_b_unique['分类组合'] == category].copy()
        
        # 转换数值列
        cat_products['售价_numeric'] = pd.to_numeric(cat_products['售价'], errors='coerce')
        cat_products['原价_numeric'] = pd.to_numeric(cat_products.get('原价', 0), errors='coerce')
        cat_products['月售_numeric'] = pd.to_numeric(cat_products.get('月售', 0), errors='coerce')
        cat_products['库存_numeric'] = pd.to_numeric(cat_products.get('库存', 0), errors='coerce')
        
        # 按月售降序排序（销量高的在前）
        cat_products = cat_products.sort_values('月售_numeric', ascending=False)
        
        # 构建每个商品的记录
        for _, product in cat_products.iterrows():
            gap_products.append({
                '缺失品类': category,
                '商品名称': product.get('商品名称', ''),
                '美团一级分类': product.get('美团一级分类', ''),
                '美团三级分类': product.get('美团三级分类', ''),
                '售价': product.get('售价_numeric', ''),
                '原价': product.get('原价_numeric', ''),
                '月售': product.get('月售_numeric', ''),
                '库存': product.get('库存_numeric', ''),
                '条码': product.get('条码', ''),
                f'店铺_{name_b}': name_b,
                '建议': '考虑引进',
            })
            total_gap_products += 1
    
    if not gap_products:
        return pd.DataFrame()
    
    df_gaps = pd.DataFrame(gap_products)
    
    # 调整列顺序，把关键信息放前面
    cols_order = ['缺失品类', '商品名称', '美团一级分类', '美团三级分类', '售价', '原价', 
                  '月售', '库存', '条码', f'店铺_{name_b}', '建议']
    # 保留实际存在的列
    cols_order = [col for col in cols_order if col in df_gaps.columns]
    df_gaps = df_gaps[cols_order]
    
    print(f"   ✅ 发现 {len(gap_categories)} 个品类缺口，共 {total_gap_products} 个商品")
    return df_gaps

def generate_final_reports(df_all_a, df_all_b, barcode_matches, fuzzy_matches, name_a, name_b, cfg=None):
    """
    生成所有报告数据
    
    新增返回：
    - df_a_unique_dedup: 去重后的本店独有商品
    - df_b_unique_dedup: 去重后的竞对独有商品
    - df_differential: 差异品对比
    - df_category_gaps: 品类缺口分析
    """
    name_a_col, name_b_col = f'商品名称_{name_a}', f'商品名称_{name_b}'
    
    matched_names_a = set()
    if not barcode_matches.empty and name_a_col in barcode_matches.columns:
        matched_names_a.update(barcode_matches[name_a_col].dropna().tolist())
    if not fuzzy_matches.empty and name_a_col in fuzzy_matches.columns:
        matched_names_a.update(fuzzy_matches[name_a_col].dropna().tolist())

    matched_names_b = set()
    if not barcode_matches.empty and name_b_col in barcode_matches.columns:
        matched_names_b.update(barcode_matches[name_b_col].dropna().tolist())
    if not fuzzy_matches.empty and name_b_col in fuzzy_matches.columns:
        matched_names_b.update(fuzzy_matches[name_b_col].dropna().tolist())

    df_a_unique = df_all_a[~df_all_a['商品名称'].isin(matched_names_a)].copy()
    if not df_a_unique.empty and '店内码' in df_a_unique.columns:
        df_a_unique.rename(columns={'店内码': f'店内码_{name_a}'}, inplace=True)
    
    # 调试：检查vector列
    print(f"   🐛 调试: df_a_unique列名={df_a_unique.columns.tolist()[:10]}... (共{len(df_a_unique.columns)}列)")
    print(f"   🐛 调试: 'vector' in df_a_unique.columns = {('vector' in df_a_unique.columns)}")

    df_b_unique = df_all_b[~df_all_b['商品名称'].isin(matched_names_b)].copy()
    if not df_b_unique.empty and '店内码' in df_b_unique.columns:
        df_b_unique.rename(columns={'店内码': f'店内码_{name_b}'}, inplace=True)
    
    # 调试：检查vector列
    print(f"   🐛 调试: df_b_unique列名={df_b_unique.columns.tolist()[:10]}... (共{len(df_b_unique.columns)}列)")
    print(f"   🐛 调试: 'vector' in df_b_unique.columns = {('vector' in df_b_unique.columns)}")

    all_matches = pd.concat([barcode_matches, fuzzy_matches], ignore_index=True)
    sales_comparison_df = pd.DataFrame()
    discount_filter_df = pd.DataFrame()  # 新增：库存与折扣联合筛选结果
    if not all_matches.empty:
        df = all_matches.copy()
        price_a, price_b = f'售价_{name_a}', f'售价_{name_b}'
        orig_a, orig_b = f'原价_{name_a}', f'原价_{name_b}'
        sales_b = f'月售_{name_b}'
        inventory_a, inventory_b = f'库存_{name_a}', f'库存_{name_b}'

        for col in [price_a, price_b, orig_a, orig_b, sales_b, inventory_a, inventory_b]:
            if col in df.columns:
                df[col] = pd.to_numeric(df[col], errors='coerce')
        
        if orig_a in df.columns and orig_b in df.columns:
            df['折扣A'] = df[price_a] / df[orig_a]
            df['折扣B'] = df[price_b] / df[orig_b]
            
            sales_comparison_df = df[
                (df[sales_b] > 0) &
                (df[inventory_a] > 0) &
                (df[inventory_b] > 0) &
                (df['折扣A'] <= df['折扣B'])
            ].sort_values(by=sales_b, ascending=False)

            # 新增：生成“库存都>0、B月售>0、且A折扣>=B折扣（均不为空）”的数据集
            try:
                discount_filter_df = df[
                    (df[inventory_a] > 0) &
                    (df[inventory_b] > 0) &
                    (df[sales_b] > 0) &
                    df['折扣A'].notna() & df['折扣B'].notna() &
                    (df['折扣A'] >= df['折扣B'])
                ].sort_values(by=sales_b, ascending=False)
            except Exception:
                discount_filter_df = pd.DataFrame()
    
    # === 新增功能 2: 差异品分析（在去重前进行，需要vector列）===
    df_differential = find_differential_products(df_a_unique, df_b_unique, name_a, name_b, cfg)
    
    # === 新增功能 1: 独有商品去重 ===
    print(f"\n📦 独有商品去重处理...")
    df_a_unique_dedup = deduplicate_unique_products(df_a_unique, name_a)
    df_b_unique_dedup = deduplicate_unique_products(df_b_unique, name_b)
    
    # === 新增功能 3: 品类缺口分析（使用去重后的数据，更清晰）===
    df_category_gaps = analyze_category_gaps(df_a_unique_dedup, df_b_unique_dedup, name_a, name_b)
    
    return (df_a_unique, df_b_unique, sales_comparison_df, discount_filter_df,
            df_a_unique_dedup, df_b_unique_dedup, df_differential, df_category_gaps)

def export_to_excel(writer, df, sheet_name):
    if df is not None and not df.empty:
        # 去掉向量列
        cols_to_drop = [col for col in df.columns if 'vector' in str(col)]
        
        # 全局：非清洗类Sheet一律移除清洗前缀列（cleaned_/standardized_brand/specs），避免干扰阅读
        is_cleaning_sheet = ('清洗数据' in sheet_name) or ('合并清洗数据对比' in sheet_name)
        if not is_cleaning_sheet:
            prefixed_cols = [col for col in df.columns if str(col).startswith('cleaned_') or str(col).startswith('standardized_brand') or str(col).startswith('specs')]
            cols_to_drop.extend(prefixed_cols)
            # 统一隐藏标准化后的分类列（有店铺后缀的形式），仅保留“美团一级/三级分类_*”
            std_category_cols = [col for col in df.columns if str(col).startswith('一级分类_') or str(col).startswith('三级分类_') or str(col).startswith('商家分类_')]
            cols_to_drop.extend(std_category_cols)

        # 对两张主要匹配结果Sheet，额外移除处理列与标准化分类，保持最简展示
        if any(keyword in sheet_name for keyword in ['条码精确匹配', '名称模糊匹配']):
            extra_cols = [col for col in df.columns if ('商家分类' in str(col)) or (str(col) in ['一级分类', '三级分类'])]
            cols_to_drop.extend(extra_cols)
            print(f"📋 {sheet_name}: 保留美团原始分类，已隐藏清洗/处理列")
        
        df = df.drop(columns=cols_to_drop, errors='ignore')

        # 自动识别A店、B店字段和公共字段
        store_a = Config.STORE_A_NAME
        store_b = Config.STORE_B_NAME
        
        # 🔍 诊断调试输出
        print(f"\n🔍 [{sheet_name}] 列排序诊断:")
        print(f"   店铺A: {store_a}")
        print(f"   店铺B: {store_b}")
        print(f"   总列数: {len(df.columns)}")
        
        a_cols = [col for col in df.columns if col.endswith(f'_{store_a}')]
        b_cols = [col for col in df.columns if col.endswith(f'_{store_b}')]
        common_cols = [col for col in df.columns if col not in a_cols + b_cols]
        
        print(f"   A店列数: {len(a_cols)}")
        print(f"   B店列数: {len(b_cols)}")
        print(f"   公共列数: {len(common_cols)}")
        if a_cols:
            print(f"   A店列示例: {a_cols[0]}")
        if b_cols:
            print(f"   B店列示例: {b_cols[0]}")

        # 定义需要ABAB排列的Sheet（对比类表格）
        abab_sheets = ['条码精确匹配', '名称模糊匹配', '差异品对比', '库存>0&A折扣']
        needs_abab = any(keyword in sheet_name for keyword in abab_sheets)
        print(f"   是否触发ABAB: {needs_abab}")
        
        if needs_abab:
            # ABAB列排列：按字段类型交替排列A店和B店的列
            print(f"📐 {sheet_name}: 启用ABAB列排列 (店铺: {store_a} vs {store_b})")
            
            # 定义核心字段顺序（按业务重要性）
            field_order = [
                '商品名称', '美团一级分类', '美团三级分类', '条码',
                '售价', '原价', '月售', '库存', '规格名称', '店内码', '折扣'
            ]
            
            # 🆕 自动发现额外字段（不在预定义列表中的A/B列）
            all_a_fields = set()
            all_b_fields = set()
            for col in a_cols:
                field_name = col.replace(f'_{store_a}', '').replace('_A', '').replace('A', '', 1)
                all_a_fields.add(field_name)
            for col in b_cols:
                field_name = col.replace(f'_{store_b}', '').replace('_B', '').replace('B', '', 1)
                all_b_fields.add(field_name)
            
            # 合并所有字段，添加到 field_order 末尾（去重）
            extra_fields = (all_a_fields | all_b_fields) - set(field_order)
            if extra_fields:
                print(f"   🔍 发现额外字段: {sorted(extra_fields)}")
                field_order.extend(sorted(extra_fields))  # 按字母顺序添加
            
            # 构建ABAB排列
            abab_cols = []
            for field in field_order:
                # 尝试多种列名变体（精确店铺名 > A/B后缀）
                col_a_variants = [f'{field}_{store_a}', f'{field}_A', f'{field}A']
                col_b_variants = [f'{field}_{store_b}', f'{field}_B', f'{field}B']
                
                # 查找A店列
                found_a = None
                for var in col_a_variants:
                    if var in df.columns:
                        found_a = var
                        break
                
                # 查找B店列
                found_b = None
                for var in col_b_variants:
                    if var in df.columns:
                        found_b = var
                        break
                
                # ABAB交替添加（优先添加配对的A-B列）
                if found_a and found_b:
                    if found_a not in abab_cols:
                        abab_cols.append(found_a)
                    if found_b not in abab_cols:
                        abab_cols.append(found_b)
                elif found_a:
                    if found_a not in abab_cols:
                        abab_cols.append(found_a)
                elif found_b:
                    if found_b not in abab_cols:
                        abab_cols.append(found_b)
            
            print(f"   ✅ ABAB核心列数: {len(abab_cols)}")
            if abab_cols:
                print(f"   前10列: {abab_cols[:10]}")
            
            # 添加特殊字段（折扣、相似度等）在ABAB列之后
            special_cols = []
            # 差异品对比特有：对比价格来源（动态识别店铺名）
            price_source_a = f'对比价格来源_{store_a}'
            price_source_b = f'对比价格来源_{store_b}'
            if price_source_a in df.columns:
                special_cols.extend([price_source_a, price_source_b])
            # 折扣字段（可能使用A/B或实际店铺名）
            if '折扣A' in df.columns:
                special_cols.extend(['折扣A', '折扣B'])
            elif f'折扣{store_a}' in df.columns:
                special_cols.extend([f'折扣{store_a}', f'折扣{store_b}'])
            # 相似度字段
            if 'composite_similarity_score' in df.columns:
                special_cols.append('composite_similarity_score')
            if 'price_diff_pct' in df.columns:  # 差异品对比：价差%
                special_cols.append('price_diff_pct')
            if 'similarity_score' in df.columns:  # 差异品对比：相似度
                special_cols.append('similarity_score')
            if '差异分析' in df.columns:
                special_cols.append('差异分析')
            if '分类一致性' in df.columns:  # 差异品对比：分类一致性检查
                special_cols.append('分类一致性')
            
            # 其余列：未匹配的A店列 -> 未匹配的B店列 -> 公共列
            a_rest = [c for c in a_cols if c not in abab_cols]
            b_rest = [c for c in b_cols if c not in abab_cols]
            common_rest = [c for c in common_cols if c not in abab_cols + special_cols]
            
            # 最终列顺序
            final_cols = abab_cols + special_cols + a_rest + b_rest + common_rest
            df = df[[c for c in final_cols if c in df.columns]]
            
            # 🔍 保存调试信息到文件
            # 清理文件名中的非法字符（Windows: < > : " / \ | ? *）
            safe_sheet_name = sheet_name.replace('/', '-').replace('\\', '-').replace(':', '-').replace('*', '-').replace('?', '-').replace('<', '-').replace('>', '-').replace('|', '-').replace('"', '')
            debug_file = f"d:/abab_debug_{safe_sheet_name}.txt"
            with open(debug_file, 'w', encoding='utf-8') as f:
                f.write(f"Sheet: {sheet_name}\n")
                f.write(f"店铺: {store_a} vs {store_b}\n\n")
                f.write(f"ABAB列({len(abab_cols)}):\n")
                for i, col in enumerate(abab_cols, 1):
                    f.write(f"  {i}. {col}\n")
                f.write(f"\nSpecial列({len(special_cols)}):\n")
                for col in special_cols:
                    f.write(f"  - {col}\n")
                f.write(f"\n最终列顺序(前20):\n")
                for i, col in enumerate(list(df.columns)[:20], 1):
                    f.write(f"  {i}. {col}\n")
            print(f"   💾 调试信息已保存到: {debug_file}")
        else:
            # 非对比类表格：默认 A列 + B列 + 其他
            ordered_cols = a_cols + b_cols + common_cols
            df = df[ordered_cols]

        # 清洗并确保工作表名合法且唯一
        try:
            existing_names = set(getattr(writer.book, 'sheetnames', []) or [])
        except Exception:
            existing_names = set()
        safe_name = _sanitize_sheet_name(sheet_name, existing_names)
        df.to_excel(writer, sheet_name=safe_name, index=False)
        logging.info(f"✅ 工作表「{safe_name}」已导出，包含 {len(df)} 条记录。")
    else:
        try:
            existing_names = set(getattr(writer.book, 'sheetnames', []) or [])
        except Exception:
            existing_names = set()
        safe_name = _sanitize_sheet_name(sheet_name, existing_names)
        pd.DataFrame([{"提示": "此分类下无数据"}]).to_excel(writer, sheet_name=safe_name, index=False)
        logging.info(f"⚠️ 工作表「{safe_name}」无数据，已导出为空白页。")

# ==============================================================================
# 5. 主执行流程 (Main Workflow)
# ==============================================================================
def main():
    # 修复 Windows 控制台编码问题（支持 emoji 输出）
    import sys
    if sys.platform == 'win32':
        try:
            import io
            sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
            sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')
        except Exception:
            pass  # 如果设置失败，继续运行
    
    print("\n" + "="*60)
    print("  商品比对分析工具 v8.5 启动中...")
    print("="*60)
    
    cfg = Config()

    # 需要在函数顶部声明，以便后续异常分支可以修改该全局变量
    global SIMPLE_FALLBACK

    # 环境变量覆盖（便于与爬虫联动）：
    # COMPARE_STORE_A_FILE / COMPARE_STORE_B_FILE: 直接指定A/B店数据文件的绝对路径
    # COMPARE_STORE_A_NAME / COMPARE_STORE_B_NAME: 覆盖店铺显示名称
    env_a_file = os.environ.get('COMPARE_STORE_A_FILE')
    env_b_file = os.environ.get('COMPARE_STORE_B_FILE')
    env_a_name = os.environ.get('COMPARE_STORE_A_NAME')
    env_b_name = os.environ.get('COMPARE_STORE_B_NAME')
    if env_a_name:
        cfg.STORE_A_NAME = env_a_name
    if env_b_name:
        cfg.STORE_B_NAME = env_b_name
    # 若提供了文件但未提供显示名，则用文件名主干作为显示名（与自动比价子进程保持一致）
    try:
        from pathlib import Path as _Path
        if (not env_a_name) and env_a_file:
            cfg.STORE_A_NAME = _Path(env_a_file).stem[:40]
        if (not env_b_name) and env_b_file:
            cfg.STORE_B_NAME = _Path(env_b_file).stem[:40]
    except Exception:
        pass

    print("\n" + "="*50)
    print("⏳ [步骤 1/7] 检测硬件加速器 (GPU/CPU)...")
    forced = getattr(Config, 'FORCE_DEVICE', None)
    
    # 检查是否有环境变量强制禁用CUDA
    if os.environ.get('CUDA_VISIBLE_DEVICES') == '':
        print("🛠️ 检测到CUDA_VISIBLE_DEVICES=''，强制使用CPU模式")
        device = 'cpu'
    elif forced in ('cuda', 'cpu'):
        device = forced
        print(f"🛠️ 按配置强制使用设备: {device}")
    else:
        # 安全的CUDA可用性检查
        cuda_available = False
        try:
            cuda_available = torch.cuda.is_available()
            if cuda_available:
                # 尝试简单的CUDA操作以确认真正可用
                test_tensor = torch.tensor([1.0]).cuda()
                del test_tensor
                torch.cuda.empty_cache()
        except Exception as cuda_error:
            print(f"⚠️ CUDA检测失败: {cuda_error}")
            cuda_available = False
        
        device = 'cuda' if cuda_available else 'cpu'
    
    if device == 'cuda':
        print("✅ 使用 GPU 运行（已安装 GPU 版 PyTorch）")
    else:
        print("ℹ️ 使用 CPU 运行（未检测到可用 GPU 或未指定使用 GPU）")

    print("\n" + "="*50)
    print("⏳ [步骤 2/7] 正在加载文本分析模型 (若本地无缓存，将自动下载)...")
    
    # 交互式选择 Sentence-BERT 模型（粗筛）
    selected_model = select_embedding_model(cfg)
    if selected_model != cfg.SENTENCE_BERT_MODEL:
        # 查找模型的友好名称
        model_display_name = selected_model
        for model_info in getattr(cfg, 'AVAILABLE_MODELS', {}).values():
            if model_info['name'] == selected_model:
                model_display_name = model_info['display_name']
                break
        cfg.SENTENCE_BERT_MODEL = selected_model
        print(f"\n📝 已切换 Sentence-BERT 到: {model_display_name}")
        print(f"   模型ID: {selected_model}")
    
    # 交互式选择 Cross-Encoder 模型（精排）
    selected_ce_model = select_cross_encoder_model(cfg)
    if selected_ce_model != cfg.ONLINE_CROSS_ENCODER:
        # 查找模型的友好名称
        ce_display_name = selected_ce_model
        for model_info in getattr(cfg, 'AVAILABLE_CROSS_ENCODERS', {}).values():
            if model_info['name'] == selected_ce_model:
                ce_display_name = model_info['display_name']
                break
        cfg.ONLINE_CROSS_ENCODER = selected_ce_model
        print(f"\n📝 已切换 Cross-Encoder 到: {ce_display_name}")
        print(f"   模型ID: {selected_ce_model}")
    
    # 环境变量覆盖本地模型路径/策略
    env_local_sbert = os.environ.get('LOCAL_SENTENCE_BERT_PATH')
    env_use_local_sbert = os.environ.get('USE_LOCAL_SENTENCE_BERT')
    if env_local_sbert:
        cfg.LOCAL_SENTENCE_BERT_PATH = env_local_sbert
        cfg.USE_LOCAL_SENTENCE_BERT = True if str(env_use_local_sbert or '1') == '1' else cfg.USE_LOCAL_SENTENCE_BERT

    env_local_ce = os.environ.get('LOCAL_CROSS_ENCODER_PATH')
    env_use_local_ce = os.environ.get('USE_LOCAL_CROSS_ENCODER')
    if env_local_ce:
        cfg.LOCAL_CROSS_ENCODER_PATH = env_local_ce
        cfg.USE_LOCAL_CROSS_ENCODER = True if str(env_use_local_ce or '1') == '1' else cfg.USE_LOCAL_CROSS_ENCODER

    # 智能检测模型是否需要下载（仅在线模型）
    model_exists = False
    if getattr(cfg, 'USE_LOCAL_SENTENCE_BERT', False) and os.path.exists(cfg.LOCAL_SENTENCE_BERT_PATH):
        model_exists = True
    else:
        model_exists = check_model_exists(cfg.SENTENCE_BERT_MODEL)
    if model_exists:
        print("⚡ 检测到本地模型缓存，快速加载中...")
    else:
        # 动态获取模型大小信息
        model_size = "未知大小"
        download_time = "几分钟"
        for model_info in getattr(cfg, 'AVAILABLE_MODELS', {}).values():
            if model_info['name'] == cfg.SENTENCE_BERT_MODEL:
                model_size = model_info.get('size', '未知大小')
                # 根据大小估算下载时间
                if 'GB' in model_size or 'gb' in model_size:
                    size_num = float(model_size.replace('~', '').replace('GB', '').replace('gb', '').strip())
                    if size_num >= 2:
                        download_time = "10-20分钟"
                    elif size_num >= 1:
                        download_time = "5-10分钟"
                    else:
                        download_time = "3-5分钟"
                elif 'MB' in model_size or 'mb' in model_size:
                    download_time = "1-3分钟"
                break
        
        print(f"💡 首次使用此模型，需要下载模型文件（{model_size}，预计{download_time}）")
        print(f"📥 下载模型: {cfg.SENTENCE_BERT_MODEL}")
        print("⏳ 请耐心等待，模型将自动缓存到本地...")
    
    try:
        # 只要 USE_LOCAL_SENTENCE_BERT=1 或本地模型目录存在，强制只用本地路径加载，彻底断网
        use_local = getattr(cfg, 'USE_LOCAL_SENTENCE_BERT', False)
        local_path = getattr(cfg, 'LOCAL_SENTENCE_BERT_PATH', None)
        local_path_exists = local_path and os.path.exists(local_path)
        for _k in ['HTTP_PROXY','HTTPS_PROXY','ALL_PROXY','http_proxy','https_proxy','all_proxy']:
            os.environ.pop(_k, None)
        os.environ['HF_HUB_OFFLINE'] = '1'
        os.environ['TRANSFORMERS_OFFLINE'] = '1'
        if use_local and local_path_exists:
            print(f"📱 强制仅用本地目录加载 Sentence-BERT: {local_path}")
            try:
                model = SentenceTransformer(local_path, device=device, use_auth_token=False)
            except Exception as e:
                if 'cuda' in str(e).lower() or 'gpu' in str(e).lower():
                    print(f"⚠️ GPU模式加载失败，切换到CPU: {e}")
                    device = 'cpu'
                    model = SentenceTransformer(local_path, device=device, use_auth_token=False)
                else:
                    raise e
        elif model_exists:
            print("📱 强制仅用本地缓存加载 Sentence-BERT...")
            # 这里依然用本地路径（不是模型名字符串），防止任何联网
            from pathlib import Path
            # 自动定位 huggingface hub 缓存下的 snapshots 子目录
            hub_cache = Path.home() / ".cache" / "huggingface" / "hub" / f"models--sentence-transformers--{cfg.SENTENCE_BERT_MODEL}" / "snapshots"
            if hub_cache.exists():
                # 取最新的快照目录
                latest = sorted(hub_cache.iterdir(), key=lambda p: p.stat().st_mtime, reverse=True)[0]
                try:
                    model = SentenceTransformer(str(latest), device=device, use_auth_token=False)
                except Exception as e:
                    if 'cuda' in str(e).lower() or 'gpu' in str(e).lower():
                        print(f"⚠️ GPU模式加载失败，切换到CPU: {e}")
                        device = 'cpu'
                        model = SentenceTransformer(str(latest), device=device, use_auth_token=False)
                    else:
                        raise e
            else:
                raise RuntimeError("未找到本地缓存快照目录")
        else:
            print("📥 首次使用，需要在线下载模型...")
            os.environ['CURL_CA_BUNDLE'] = ''
            os.environ['REQUESTS_CA_BUNDLE'] = ''
            try:
                model = SentenceTransformer(cfg.SENTENCE_BERT_MODEL, device=device, use_auth_token=False)
            except Exception as e:
                if 'cuda' in str(e).lower() or 'gpu' in str(e).lower():
                    print(f"⚠️ GPU模式加载失败，切换到CPU: {e}")
                    device = 'cpu'
                    model = SentenceTransformer(cfg.SENTENCE_BERT_MODEL, device=device, use_auth_token=False)
                else:
                    raise e
            print("✅ 模型下载并加载成功！下次运行将直接使用缓存。")

        model.encode(["测试"], show_progress_bar=False)  # 测试模型是否可用
        print("✅ Sentence-BERT 模型加载成功！")

        # 尝试加载Cross-Encoder模型
        cross_encoder = None
        try:
            # 允许通过环境变量强制禁用 Cross-Encoder（避免联网或潜在卡顿）
            if os.environ.get('DISABLE_CROSS_ENCODER', '0') == '1':
                print("⚙️ 已根据环境变量禁用 Cross-Encoder 精排（DISABLE_CROSS_ENCODER=1）")
                cross_encoder = None
            elif getattr(cfg, 'USE_LOCAL_CROSS_ENCODER', False):
                cross_encoder_path = cfg.LOCAL_CROSS_ENCODER_PATH
                if os.path.exists(cross_encoder_path):
                    cross_encoder = CrossEncoder(cross_encoder_path, device=device) if CrossEncoder else None
                    print("✅ 本地Cross-Encoder模型加载成功！")
                else:
                    print("⚠️ 本地Cross-Encoder模型路径不存在，将使用在线模型")
                    cross_encoder = CrossEncoder(cfg.ONLINE_CROSS_ENCODER, device=device) if CrossEncoder else None
            else:
                print("⏳ 正在加载在线Cross-Encoder模型...")
                cross_encoder = CrossEncoder(cfg.ONLINE_CROSS_ENCODER, device=device) if CrossEncoder else None
                if cross_encoder:
                    print("✅ Cross-Encoder模型加载成功！")
        except Exception as ce_error:
            error_msg = str(ce_error)
            print(f"\n⚠️ Cross-Encoder模型加载失败:")
            print(f"   错误: {error_msg[:150]}")
            
            # 判断错误类型并给出针对性建议
            if "couldn't connect" in error_msg or "Connection" in error_msg:
                print(f"\n🌐 网络连接问题检测到！")
                print(f"   当前尝试下载的模型: {cfg.ONLINE_CROSS_ENCODER}")
                print(f"\n💡 快速解决方案:")
                print(f"   1. ⚡ 使用镜像源（推荐）:")
                print(f"      在终端执行: $env:HF_ENDPOINT='https://hf-mirror.com'")
                print(f"      然后重新运行比价脚本")
                print(f"\n   2. 🔌 禁用Cross-Encoder（快速但准确率略降）:")
                print(f"      在终端执行: $env:DISABLE_CROSS_ENCODER='1'")
                print(f"      然后重新运行比价脚本")
                print(f"\n   3. 📥 下载到本地（一次性，永久解决）:")
                print(f"      使用镜像下载模型到本地，然后修改配置:")
                print(f"      USE_LOCAL_CROSS_ENCODER = True")
                print(f"      LOCAL_CROSS_ENCODER_PATH = 'D:/AI_Models/cross-encoder-model'")
            
            print(f"\n⚙️  当前降级方案: 使用纯余弦相似度（准确率约降低5-10%）")
            print(f"   ✓ 不影响正常运行，仅精排能力略有下降")
            cross_encoder = None

    except Exception as e:
        print(f"❌ 模型加载失败: {e}")
        print("\n🔧 可能的解决方案:")
        print("1. 网络问题解决:")
        print("   - 检查网络连接是否稳定")
        print("   - 如果使用代理，请确保代理设置正确")
        print("   - 尝试切换网络或稍后重试")
        print("\n2. 依赖库更新:")
        print("   pip install --upgrade sentence-transformers torch transformers")
        print("\n3. 手动下载模型:")
        print("   - 访问: https://huggingface.co/sentence-transformers/paraphrase-multilingual-mpnet-base-v2")
        print("   - 下载模型文件到本地目录")
        print("\n4. 使用镜像源:")
        print("   - 设置环境变量: HF_ENDPOINT=https://hf-mirror.com")
        print("\n正在尝试使用备用方案...")
        
        if SIMPLE_FALLBACK:
            # 仅在明确允许时才降级
            SIMPLE_FALLBACK = True
            model = None
            cross_encoder = None
            print("⚡ 已切换到简化兜底模式：不下载模型，使用轻量文本相似度完成匹配")
        else:
            print("🚫 已禁止降级兜底模式（ALLOW_SIMPLE_FALLBACK!=1）。为保证准确率，程序将退出。")
            print("👉 解决方案：")
            print("   1) 离线本地模型：设置 USE_LOCAL_SENTENCE_BERT=1 和 LOCAL_SENTENCE_BERT_PATH=本地模型目录")
            print("   2) 本地 CrossEncoder（可选）：设置 USE_LOCAL_CROSS_ENCODER=1 和 LOCAL_CROSS_ENCODER_PATH=本地目录")
            print("   3) 使用镜像：设置 HF_ENDPOINT=https://hf-mirror.com 并确保网络直连")
            sys.exit(1)

    print("\n" + "="*50)
    print("⏳ [步骤 3/7] 正在查找本地文件...")
    
    # 优先级：环境变量 > 上传目录 > 配置文件
    store_a_file = None
    store_b_file = None
    
    try:
        # 1. 优先使用环境变量指定的文件
        if env_a_file and os.path.exists(env_a_file) and env_b_file and os.path.exists(env_b_file):
            store_a_file = env_a_file
            store_b_file = env_b_file
            print(f"✅ 通过环境变量指定文件:")
            print(f"  本店: {store_a_file}")
            print(f"  竞对: {store_b_file}")
        
        # 2. 尝试从上传目录检测文件（如果启用）
        elif getattr(cfg, 'USE_UPLOAD_DIRS', True):
            store_a_file, store_b_file, auto_name_a, auto_name_b = detect_files_from_upload_dirs(cfg)
            
            print(f"\n🔍 调试信息:")
            print(f"  检测到的文件A: {store_a_file}")
            print(f"  检测到的文件B: {store_b_file}")
            print(f"  店铺名A: {auto_name_a}")
            print(f"  店铺名B: {auto_name_b}")
            
            # 如果检测到文件，更新店铺名称
            if store_a_file and store_b_file:
                cfg.STORE_A_NAME = auto_name_a
                cfg.STORE_B_NAME = auto_name_b
                print(f"\n📝 已自动识别店铺名称:")
                print(f"  🏪 本店: {cfg.STORE_A_NAME}")
                print(f"  🏬 竞对: {cfg.STORE_B_NAME}")
            else:
                print(f"\n⚠️ 文件检测失败，将回退到配置文件模式")
        
        # 3. 回退到配置文件指定的文件名
        if not store_a_file or not store_b_file:
            print("\n🔄 使用配置文件中指定的文件名...")
            if not store_a_file:
                store_a_file = get_local_filepath(cfg.STORE_A_FILENAME)
            if not store_b_file:
                store_b_file = get_local_filepath(cfg.STORE_B_FILENAME)
        
    except Exception as e:
        print(f"[错误] 文件查找失败: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

    if not all([store_a_file, store_b_file]):
        print("\n❌ Missing required store files. Please ensure:")
        base_dir = os.path.dirname(os.path.abspath(__file__))
        upload_a = os.path.join(base_dir, getattr(cfg, 'UPLOAD_DIR_STORE_A', 'upload/store_a'))
        upload_b = os.path.join(base_dir, getattr(cfg, 'UPLOAD_DIR_STORE_B', 'upload/store_b'))
        print(f"  1. Put your store Excel file in: {upload_a}")
        print(f"  2. Put competitor Excel file in: {upload_b}")
        print(f"  OR")
        print(f"  3. Set correct filenames in config, OR")
        print(f"  4. Use environment variables COMPARE_STORE_* to specify absolute paths")
        print(f"\nCurrent script directory: {base_dir}")
        sys.exit(1)

    print("\n" + "="*50)
    print(f"⏳ [步骤 4/7] 正在处理「{cfg.STORE_A_NAME}」的数据...")
    try:
        cache_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), cfg.EMBEDDING_CACHE_FILE)
        print(f"💾 启用向量缓存: {os.path.basename(cache_path)}")
        df_a_barcode, df_a_no_barcode = load_and_process_store_data(store_a_file, model, cache_path, role='A')
    except Exception as e:
        print(f"[错误] 处理A店数据失败: {e}")
        sys.exit(1)

    print(f"\n⏳ [步骤 4/7] 正在处理「{cfg.STORE_B_NAME}」的数据...")
    try:
        cache_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), cfg.EMBEDDING_CACHE_FILE)
        print(f"💾 启用向量缓存: {os.path.basename(cache_path)}")
        df_b_barcode, df_b_no_barcode = load_and_process_store_data(store_b_file, model, cache_path, role='B')
    except Exception as e:
        print(f"[错误] 处理B店数据失败: {e}")
        sys.exit(1)

    print("\n" + "="*50)
    print("⏳ [步骤 5/7] 正在进行商品匹配...")
    try:
        # --- 阶段1: 条码精确匹配 ---
        barcode_matches_df = match_by_barcode(df_a_barcode, df_b_barcode, cfg.STORE_A_NAME, cfg.STORE_B_NAME)
        logging.info(f"【阶段1/3】条码精确匹配找到 {len(barcode_matches_df)} 个商品。")

        # --- 准备模糊匹配池 ---
        # 找出在条码匹配中未成功的商品
        if not barcode_matches_df.empty:
            # 正确的逻辑：合并后的条码列就叫'条码'，直接用它来获取已匹配的条码列表
            matched_barcodes = barcode_matches_df['条码'].unique()
            
            unmatched_a_with_barcode = df_a_barcode[~df_a_barcode['条码'].isin(matched_barcodes)]
            unmatched_b_with_barcode = df_b_barcode[~df_b_barcode['条码'].isin(matched_barcodes)]
        else:
            unmatched_a_with_barcode = df_a_barcode
            unmatched_b_with_barcode = df_b_barcode

        # 合并【有条码但未匹配上的】和【无条码的】商品，形成完整的模糊匹配池
        fuzzy_pool_a = pd.concat([unmatched_a_with_barcode, df_a_no_barcode], ignore_index=True)
        fuzzy_pool_b = pd.concat([unmatched_b_with_barcode, df_b_no_barcode], ignore_index=True)

        logging.info(f"【准备模糊匹配】A店进入模糊匹配池的商品数: {len(fuzzy_pool_a)} (有码未匹配: {len(unmatched_a_with_barcode)}, 无码: {len(df_a_no_barcode)})")
        logging.info(f"【准备模糊匹配】B店进入模糊匹配池的商品数: {len(fuzzy_pool_b)} (有码未匹配: {len(unmatched_b_with_barcode)}, 无码: {len(df_b_no_barcode)})")

        # === 可选：按B侧分类自动限域（减少A侧搜索空间，提高速度且不降准确率） ===
        try:
            auto_scope_cat1 = os.environ.get('AUTO_SCOPE_BY_B_CAT1', '1') == '1'
            auto_scope_cat3 = os.environ.get('AUTO_SCOPE_BY_B_CAT3', '0') == '1'
            max_cat1 = int(os.environ.get('SCOPE_CAT1_MAX', '3'))
            max_cat3 = int(os.environ.get('SCOPE_CAT3_MAX', '6'))

            a_before = len(fuzzy_pool_a)
            scope_msgs = []
            if auto_scope_cat1 and '一级分类' in fuzzy_pool_b.columns and '一级分类' in fuzzy_pool_a.columns:
                cats1 = sorted(set(str(x) for x in fuzzy_pool_b['一级分类'].dropna().unique()))
                if 0 < len(cats1) <= max_cat1:
                    fuzzy_pool_a = fuzzy_pool_a[fuzzy_pool_a['一级分类'].astype(str).isin(cats1)]
                    scope_msgs.append(f"按B的一级分类限域({len(cats1)}类) → A: {a_before} -> {len(fuzzy_pool_a)}")
                    a_before = len(fuzzy_pool_a)

            if auto_scope_cat3 and '三级分类' in fuzzy_pool_b.columns and '三级分类' in fuzzy_pool_a.columns:
                cats3 = sorted(set(str(x) for x in fuzzy_pool_b['三级分类'].dropna().unique()))
                if 0 < len(cats3) <= max_cat3:
                    fuzzy_pool_a = fuzzy_pool_a[fuzzy_pool_a['三级分类'].astype(str).isin(cats3)]
                    scope_msgs.append(f"按B的三级分类限域({len(cats3)}类) → A: {a_before} -> {len(fuzzy_pool_a)}")

            for m in scope_msgs:
                logging.info(f"【自动限域】{m}")
            if not scope_msgs:
                logging.info("【自动限域】未生效（B分类数量超过阈值或未启用）")
        except Exception as _:
            logging.info("【自动限域】执行出错，已忽略")
        # 额外提示：可能的耗时与模式
        try:
            use_simple = SIMPLE_FALLBACK or (len(fuzzy_pool_a) == 0 or len(fuzzy_pool_b) == 0 or (hasattr(fuzzy_pool_a['vector'].iloc[0], 'shape') and fuzzy_pool_a['vector'].iloc[0].shape == (1,)))
        except Exception:
            use_simple = SIMPLE_FALLBACK
        k_hard = int(os.environ.get('MATCH_TOPK_HARD', '20'))
        k_soft = int(os.environ.get('MATCH_TOPK_SOFT', '100'))
        gpu_sim = (os.environ.get('USE_TORCH_SIM','0')=='1' and torch.cuda.is_available())
        mode_text = '简化兜底(无向量/无CE)' if use_simple else f"向量+可选CE精排{' + GPU相似度' if gpu_sim else ''}"
        print(f"ℹ️ 匹配模式: {mode_text}，Top-K: 硬{k_hard}/软{k_soft}；样本规模 A={len(fuzzy_pool_a)} / B={len(fuzzy_pool_b)}")
        # 提醒任何过滤或采样配置
        if os.environ.get('COMPARE_CAT1_LIST') or os.environ.get('COMPARE_CAT1_REGEX'):
            print("🔎 已按一级分类进行预过滤 (COMPARE_CAT1_LIST/COMPARE_CAT1_REGEX)")
        if os.environ.get('COMPARE_MAX_A') or os.environ.get('COMPARE_MAX_B'):
            print(f"🧪 采样限制: A={os.environ.get('COMPARE_MAX_A') or '不限'} / B={os.environ.get('COMPARE_MAX_B') or '不限'}")
        if len(fuzzy_pool_a) * len(fuzzy_pool_b) > 200000:
            print("⏱️ 数据量较大，匹配可能需要几分钟，请耐心等待...（期间会有进度条）")


        # --- 阶段2: 硬分类优先匹配 (针对完整的模糊匹配池) ---
        logging.info(f"【阶段2/3】正在对所有未匹配商品进行“硬分类优先”匹配...")
        hard_matches_df, unmatched_a_df, unmatched_b_df = perform_hard_category_matching(
            fuzzy_pool_a, fuzzy_pool_b, cfg.STORE_A_NAME, cfg.STORE_B_NAME, cross_encoder, cfg
        )
        logging.info(f"✅ 硬分类匹配找到 {len(hard_matches_df)} 个匹配。")
        logging.info(f"   - 剩余A店商品: {len(unmatched_a_df)}, B店商品: {len(unmatched_b_df)} 进入下一阶段。")

        # --- 阶段3: 软分类兜底匹配 (针对剩余商品) ---
        logging.info(f"【阶段3/3】正在对剩余商品进行“软分类兜底”匹配...")
        soft_matches_df = perform_soft_fuzzy_matching(
            unmatched_a_df, unmatched_b_df, cfg.STORE_A_NAME, cfg.STORE_B_NAME, cross_encoder, cfg
        )
        logging.info(f"✅ 软分类兜底匹配找到 {len(soft_matches_df)} 个额外匹配。")

        # --- 合并所有模糊匹配结果 ---
        fuzzy_matches_df = pd.concat([hard_matches_df, soft_matches_df], ignore_index=True)
        
        print(f"✅ 名称模糊匹配总共找到 {len(fuzzy_matches_df)} 个匹配 (硬分类: {len(hard_matches_df)}, 软兜底: {len(soft_matches_df)})")
        print("✅ [步骤 5/7] 商品匹配完成！")
    except Exception as e:
        print(f"[错误] 商品匹配失败: {e}")
        sys.exit(1)

    print("\n" + "="*50)
    print("⏳ [步骤 6/7] 正在生成最终报告...")
    try:
        df_all_a = pd.concat([df_a_barcode, df_a_no_barcode], ignore_index=True)
        df_all_b = pd.concat([df_b_barcode, df_b_no_barcode], ignore_index=True)
        (df_a_unique, df_b_unique, df_sales_comp, df_discount_filter,
         df_a_unique_dedup, df_b_unique_dedup, df_differential, df_category_gaps) = generate_final_reports(
            df_all_a, df_all_b, barcode_matches_df, fuzzy_matches_df, cfg.STORE_A_NAME, cfg.STORE_B_NAME, cfg
        )
        
    # 按需求变更：不再统计/导出“有条码但未匹配”信息
        
        print("✅ [步骤 6/7] 报告生成完毕！")
    except Exception as e:
        print(f"[错误] 生成报告失败: {e}")
        sys.exit(1)

    print("\n" + "="*50)
    
    # 生成带时间戳的文件名，避免文件被占用；统一导出到 reports/ 目录
    import datetime
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    output_file_name = f'matched_products_comparison_final_{timestamp}.xlsx'
    # 构造输出目录并确保存在
    script_dir = os.path.dirname(os.path.abspath(__file__))
    out_dir = os.path.join(script_dir, getattr(cfg, 'OUTPUT_DIR', 'reports'))
    os.makedirs(out_dir, exist_ok=True)
    output_path = os.path.join(out_dir, output_file_name)

    print(f"⏳ [步骤 7/7] 正在将所有结果导出到 Excel 文件: {output_path}...")
    
    try:
        
        # 检查并删除可能存在的同名文件
        if os.path.exists(output_path):
            try:
                os.remove(output_path)
                import time
                time.sleep(0.5)  # 短暂等待确保文件被释放
            except Exception as e:
                print(f"⚠️ 警告：无法删除现有文件 {output_path}: {e}")
        
        with pd.ExcelWriter(output_path, engine='openpyxl') as writer:
            # === 核心匹配结果（条码匹配和名称匹配严格分离）===
            export_to_excel(writer, barcode_matches_df, '1-条码精确匹配')
            
            # 📋 2-名称模糊匹配：对齐手动比价，空表也要生成一个空白Sheet，便于结构一致
            print(f"📋 2-名称模糊匹配(无条码): 匹配条数 {len(fuzzy_matches_df)}（空表也会导出）")
            export_to_excel(writer, fuzzy_matches_df, '2-名称模糊匹配(无条码)')
            
            # === 新增：差异品对比 ===
            if not df_differential.empty:
                print(f"📊 差异品对比: {len(df_differential)} 对差异品匹配")
                export_to_excel(writer, df_differential, '3-差异品对比')
            
            # === 独有商品（原始+去重版本） ===
            export_to_excel(writer, df_a_unique, f'4-{cfg.STORE_A_NAME}-独有商品(全部)')
            export_to_excel(writer, df_b_unique, f'5-{cfg.STORE_B_NAME}-独有商品(全部)')
            # 按需求变更：不再导出“6-销量对比(B店畅销且我店有优势)”
            # 新增：A折扣>=B折扣且双方库存>0、B月售>0（简化命名）
            export_to_excel(writer, df_discount_filter, '9-库存>0&A折扣≥B折扣')
            
            # 导出去重后的独有商品
            if not df_a_unique_dedup.empty:
                print(f"  [去重A] {cfg.STORE_A_NAME}-独有商品(去重): {len(df_a_unique_dedup)} 种商品")
                export_to_excel(writer, df_a_unique_dedup, f'6-{cfg.STORE_A_NAME}-独有商品(去重)')
            if not df_b_unique_dedup.empty:
                print(f"  [去重B] {cfg.STORE_B_NAME}-独有商品(去重): {len(df_b_unique_dedup)} 种商品")
                export_to_excel(writer, df_b_unique_dedup, f'7-{cfg.STORE_B_NAME}-独有商品(去重)')
            
            # 导出品类缺口分析
            if not df_category_gaps.empty:
                print(f"  [缺口] 品类缺口分析: {len(df_category_gaps)} 个缺失品类")
                export_to_excel(writer, df_category_gaps, '8-品类缺口分析')
            
            # 清洗数据导出：可配置开关
            if getattr(cfg, 'EXPORT_CLEANED_SHEETS', True):
                print(f"✅ 正在导出清洗后的数据...")

                # 合并A店和B店的所有数据（包括有条码和无条码的）
                df_a_all = pd.concat([df_a_barcode, df_a_no_barcode], ignore_index=True) if not df_a_no_barcode.empty else df_a_barcode
                df_b_all = pd.concat([df_b_barcode, df_b_no_barcode], ignore_index=True) if not df_b_no_barcode.empty else df_b_barcode

                # 提取清洗后的列（包含所有处理过的字段和分类对比）
                cleaned_cols = [
                    '商品名称', 'cleaned_商品名称',
                    '美团一级分类', '一级分类', 'cleaned_一级分类',
                    '美团三级分类', '三级分类', 'cleaned_三级分类',
                    'standardized_brand', 'specs',
                    '商家分类', '条码', '店内码', '原价', '售价', '月售', '库存'
                ]

                # A店清洗数据
                cleaned_cols_a = [col for col in cleaned_cols if col in df_a_all.columns]
                if len(cleaned_cols_a) > 0:
                    df_a_cleaned = df_a_all[cleaned_cols_a].copy()
                    df_a_cleaned['数据源'] = cfg.STORE_A_NAME
                    export_to_excel(writer, df_a_cleaned, f'6-{cfg.STORE_A_NAME}-清洗数据')

                # B店清洗数据
                cleaned_cols_b = [col for col in cleaned_cols if col in df_b_all.columns]
                if len(cleaned_cols_b) > 0:
                    df_b_cleaned = df_b_all[cleaned_cols_b].copy()
                    df_b_cleaned['数据源'] = cfg.STORE_B_NAME
                    export_to_excel(writer, df_b_cleaned, f'7-{cfg.STORE_B_NAME}-清洗数据')

                # 合并清洗数据对比（只包含两店都有的列）
                common_cleaned_cols = list(set(cleaned_cols_a) & set(cleaned_cols_b))
                if len(common_cleaned_cols) > 0:
                    try:
                        df_combined_cleaned = pd.concat([
                            df_a_all[common_cleaned_cols].assign(数据源=cfg.STORE_A_NAME),
                            df_b_all[common_cleaned_cols].assign(数据源=cfg.STORE_B_NAME)
                        ], ignore_index=True)
                        export_to_excel(writer, df_combined_cleaned, '8-合并清洗数据对比')
                        print(f"✅ 清洗数据已导出到独立Sheet中，便于查阅对比")
                    except Exception as e:
                        print(f"⚠️ 合并清洗数据时出错: {e}")
            else:
                print("ℹ️ 已根据配置关闭清洗数据 Sheet 的导出（6/7/8 号表）。")
        
        print(f"✅ [步骤 7/7] Excel 文件导出成功！已保存至: {output_path}")
    except Exception as e:
        print(f"[错误] Excel导出失败: {e}")
        sys.exit(1)

    print("\n" + "="*50)
    print(f"🎉 全部流程完成！")
    print("="*50)

if __name__ == '__main__':
    main()
